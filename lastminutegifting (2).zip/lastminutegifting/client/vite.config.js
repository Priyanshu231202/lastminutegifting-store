import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// In dev, forward API + uploaded photos to the Node server on :5000
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': 'http://localhost:5000',
      '/uploads': 'http://localhost:5000',
    },
  },
})
