import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../components/Icon';
import ProductRail from '../components/ProductRail';
import ProductImage from '../components/ProductImage';
import { useStore } from '../store';

const slides = [
  { kicker: 'Forgot a birthday? We didn’t.', title: 'Gifts at their door in 2–4 hours', text: 'Order till 8 PM for same-day delivery anywhere in Delhi — gift-wrapped, with your note.', cta: 'Shop same-day gifts', to: '/collections/same-day', theme: 'coral', icon: 'bolt' },
  { kicker: 'Corporate & bulk gifting', title: 'Your logo on gifts people actually keep', text: 'Laptop bags, diaries, bottles and keychains with your logo. Bulk pricing from 50 units.', cta: 'Get a bulk quote', to: '/bulk-enquiry', theme: 'ink', icon: 'building' },
  { kicker: 'Festive season is here', title: 'Diwali gifting, sorted early', text: 'Diary & pen gift sets, flask sets and card holders for family, clients and teams.', cta: 'Explore festive gifts', to: '/collections/diwali', theme: 'gold', icon: 'sparkle' },
];

const occasionArt = {
  birthday: ['#e4572e', '🎂'], anniversary: ['#b23a5b', '💞'], corporate: ['#1d1a26', '🤝'], 'employee-welcome': ['#2f6b5a', '👋'],
  diwali: ['#c7811a', '🪔'], farewell: ['#4a5a8a', '✈️'], housewarming: ['#6b4f2e', '🏡'], 'for-him': ['#2b3a4a', '🎩'], 'for-her': ['#9a4a7a', '🌸'], eco: ['#35533a', '🌿'],
};

const faqs = [
  ['How fast can you deliver?', 'Within Delhi we deliver in 2–4 hours for same-day items. Orders confirmed by 8 PM go out the same day. Noida, Gurugram and Chandigarh are coming soon.'],
  ['How do I place an order?', 'Add gifts to your gift list and send the enquiry. We call or WhatsApp you within minutes to confirm stock, personalisation and delivery time, then share a payment link.'],
  ['Can you add names or our company logo?', 'Yes — laser engraving and UV printing on bottles and mugs, and logo engraving on every keychain (already included in keychain prices). Mention it in your gift list or bulk enquiry.'],
  ['Do you offer bulk / corporate pricing?', 'Yes. Orders of 50+ units get special pricing, free branding mock-ups and dispatch to multiple addresses. Use the Bulk / Corporate form for a quote.'],
];

export default function Home() {
  const { catalog } = useStore();
  const [slide, setSlide] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setSlide((s) => (s + 1) % slides.length), 6000);
    return () => clearInterval(t);
  }, []);
  const cats = (catalog.categories || []).filter((c) => c.count > 0);

  return (
    <>
      {/* Quick category chips */}
      <div className="chips-strip">
        <div className="container chips">
          <Link to="/collections/same-day" className="chip hot"><Icon name="bolt" size={16} /> Same-day</Link>
          {cats.flatMap((c) => (c.subs || []).filter((x) => x.count > 0).map((x) => <Link key={c.slug + x.slug} to={`/collections/${c.slug}?sub=${x.slug}`} className="chip">{x.name}</Link>))}
          <Link to="/trophies" className="chip">Trophies & Awards</Link>
        </div>
      </div>

      {/* Hero */}
      <section className="hero container">
        <div className="hero-track" style={{ transform: `translateX(-${slide * 100}%)` }}>
          {slides.map((s, i) => (
            <div key={i} className={`hero-slide theme-${s.theme}`} aria-hidden={i !== slide}>
              <div className="hero-copy">
                <span className="kicker"><Icon name={s.icon} size={15} /> {s.kicker}</span>
                <h1>{s.title}</h1>
                <p>{s.text}</p>
                <Link to={s.to} className="btn btn-light" tabIndex={i === slide ? 0 : -1}>{s.cta} <Icon name="chevron" size={16} /></Link>
              </div>
              <div className="hero-art" aria-hidden="true">
                <div className="gift-stack">
                  <span className="box b1" /><span className="box b2" /><span className="box b3" />
                  <span className="ribbon r1" /><span className="ribbon r2" /><span className="ribbon r3" />
                </div>
                <div className="hero-badge"><strong>2–4 hr</strong><small>delivery</small></div>
              </div>
            </div>
          ))}
        </div>
        <div className="hero-dots">
          {slides.map((_, i) => <button key={i} className={i === slide ? 'active' : ''} onClick={() => setSlide(i)} aria-label={`Slide ${i + 1}`} />)}
        </div>
      </section>

      {/* Trust row */}
      <div className="container trust-row">
        {[['clock', 'Order till 8 PM', 'same-day in Delhi'], ['gift', 'Free gift wrap', '+ handwritten note'], ['pen', 'Name & logo', 'personalisation'], ['shield', 'Pay after confirming', 'no advance to enquire']].map(([i, a, b]) => (
          <div key={a}><Icon name={i} size={22} /><span><strong>{a}</strong> {b}</span></div>
        ))}
      </div>

      {/* Categories — one tile per sub-category that has products, plus trophies */}
      <section className="section">
        <div className="container">
          <div className="section-head"><div><h2>Shop by category</h2><p className="muted">Everything we stock, ready to gift or brand.</p></div></div>
          <div className="cat-grid">
            {cats.flatMap((c) => (c.subs || []).filter((s) => s.count > 0).map((s) => (
              <Link key={c.slug + s.slug} to={`/collections/${c.slug}?sub=${s.slug}`} className="cat-tile">
                <ProductImage product={{ category: c.slug, name: s.name, image: s.image }} />
                <div className="cat-info"><strong>{s.name}</strong><span>{s.count} {c.slug === 'keychains' ? 'designs' : 'gifts'}</span></div>
              </Link>
            )))}
            <Link to="/trophies" className="cat-tile">
              <ProductImage product={{ category: 'gift-sets', name: 'Trophies & Awards', image: '/uploads/catalogue/tro-hero.jpg' }} />
              <div className="cat-info"><strong>Trophies & Awards</strong><span>Acrylic, glass, metal & medals</span></div>
            </Link>
          </div>
        </div>
      </section>

      <ProductRail
        title="Loved by Delhi"
        subtitle="Our most-gifted picks this month"
        tabs={[
          { label: 'Bestsellers', params: { flag: 'bestseller' }, to: '/collections/bestsellers' },
          { label: 'New arrivals', params: { flag: 'newArrival', sort: 'newest' }, to: '/collections/new' },
          { label: 'Same-day delivery', params: { sameDay: '1' }, to: '/collections/same-day' },
        ]}
      />

      {/* Occasions */}
      <section className="section tint">
        <div className="container">
          <div className="section-head"><div><h2>Gifts for every moment</h2><p className="muted">Pick the occasion, we’ll handle the rest.</p></div></div>
          <div className="occ-grid">
            {(catalog.occasions || []).map((o) => {
              const [color, emoji] = occasionArt[o.slug] || ['#1d1a26', '🎁'];
              return (
                <Link key={o.slug} to={`/collections/${o.slug}`} className="occ-card" style={{ '--occ': color }}>
                  <span className="occ-emoji" aria-hidden="true">{emoji}</span>
                  <strong>{o.name}</strong>
                  <span className="occ-go">Shop <Icon name="chevron" size={14} /></span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <ProductRail
        title="Corporate favourites"
        subtitle="Brandable gifts for clients and teams"
        tabs={[
          { label: 'Client gifts', params: { occasion: 'corporate' }, to: '/collections/corporate' },
          { label: 'Welcome kits', params: { occasion: 'employee-welcome' }, to: '/collections/employee-welcome' },
          { label: 'Diwali', params: { occasion: 'diwali' }, to: '/collections/diwali' },
        ]}
      />

      {/* Bulk banner */}
      <section className="container">
        <div className="bulk-banner">
          <div>
            <span className="kicker"><Icon name="building" size={15} /> For companies, events & weddings</span>
            <h2>Need 50, 500 or 5,000 gifts?</h2>
            <p>Tell us the budget and headcount — we’ll send options with your logo mocked up, bulk pricing and a delivery plan within 24 hours.</p>
            <div className="bulk-points">
              <span><Icon name="check" size={16} /> Free logo mock-ups</span>
              <span><Icon name="check" size={16} /> GST invoice</span>
              <span><Icon name="check" size={16} /> Multi-address dispatch</span>
            </div>
          </div>
          <Link to="/bulk-enquiry" className="btn btn-primary btn-lg">Get a bulk quote <Icon name="chevron" size={18} /></Link>
        </div>
      </section>

      {/* How it works */}
      <section className="section">
        <div className="container">
          <div className="section-head center-head"><div><h2>How ordering works</h2><p className="muted">No account, no advance payment to enquire.</p></div></div>
          <ol className="steps">
            <li><span>1</span><strong>Build your gift list</strong><p>Add products, quantities and any name or logo you want on them.</p></li>
            <li><span>2</span><strong>We confirm in minutes</strong><p>Our team calls or WhatsApps to confirm stock, price and delivery slot.</p></li>
            <li><span>3</span><strong>Pay & relax</strong><p>Pay via the link we share. Your gift arrives wrapped, in 2–4 hours.</p></li>
          </ol>
        </div>
      </section>

      {/* FAQ */}
      <section className="section tint">
        <div className="container narrow">
          <div className="section-head center-head"><div><h2>Questions, answered</h2></div></div>
          <div className="faq">
            {faqs.map(([q, a]) => (
              <details key={q}><summary>{q}<Icon name="plus" size={18} /></summary><p>{a}</p></details>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
