import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/Icon';
import ProductImage from '../../components/ProductImage';
import { api, inr } from '../../api';
import { useStore } from '../../store';

const getToken = () => { try { return sessionStorage.getItem('lmg_admin') || ''; } catch { return ''; } };
const setTokenStore = (t) => { try { t ? sessionStorage.setItem('lmg_admin', t) : sessionStorage.removeItem('lmg_admin'); } catch { /* ignore */ } };

export default function Admin() {
  const [token, setToken] = useState(getToken);
  const [ok, setOk] = useState(false);
  const [tab, setTab] = useState('enquiries');

  useEffect(() => {
    if (!token) return;
    api.admin.check(token).then(() => setOk(true)).catch(() => { setOk(false); setToken(''); setTokenStore(''); });
  }, [token]);

  if (!ok) return <Login onLogin={(t) => { setTokenStore(t); setToken(t); }} failed={!!getToken() === false && token === ''} />;

  return (
    <div className="admin">
      <aside className="admin-side">
        <Link to="/" className="logo-text light">lastminute<b>gifting</b></Link>
        <small>Admin</small>
        {[['enquiries', 'Enquiries', 'mail'], ['products', 'Products', 'gift'], ['settings', 'Store settings', 'sparkle']].map(([k, l, i]) => (
          <button key={k} className={tab === k ? 'active' : ''} onClick={() => setTab(k)}><Icon name={i} size={18} /> {l}</button>
        ))}
        <button className="logout" onClick={() => { setTokenStore(''); setToken(''); setOk(false); }}>Log out</button>
      </aside>
      <section className="admin-main">
        {tab === 'enquiries' && <Enquiries token={token} />}
        {tab === 'products' && <Products token={token} />}
        {tab === 'settings' && <Settings token={token} />}
      </section>
    </div>
  );
}

function Login({ onLogin }) {
  const [t, setT] = useState('');
  const [err, setErr] = useState('');
  const submit = async (e) => {
    e.preventDefault();
    try { await api.admin.check(t); onLogin(t); } catch { setErr('Wrong admin password'); }
  };
  return (
    <div className="admin-login">
      <form className="card form" onSubmit={submit}>
        <span className="logo-text">lastminute<b>gifting</b></span>
        <h2>Admin login</h2>
        <label className="field"><span>Admin password</span><input type="password" value={t} onChange={(e) => setT(e.target.value)} autoFocus /></label>
        {err && <p className="err-box">{err}</p>}
        <button className="btn btn-primary block">Log in</button>
        <p className="fine">Set it with ADMIN_TOKEN in server/.env</p>
      </form>
    </div>
  );
}

/* ---------------- Enquiries ---------------- */
const STATUSES = ['new', 'contacted', 'quoted', 'won', 'lost'];

function Enquiries({ token }) {
  const [list, setList] = useState(null);
  const [filter, setFilter] = useState('');
  const [open, setOpen] = useState(null);
  const load = () => api.admin.enquiries(token).then(setList);
  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const setStatus = async (id, status) => {
    await api.admin.updateEnquiry(token, id, { status });
    setList((l) => l.map((e) => (e.id === id ? { ...e, status } : e)));
  };
  const remove = async (id) => {
    if (!confirm('Delete this enquiry?')) return;
    await api.admin.deleteEnquiry(token, id);
    setList((l) => l.filter((e) => e.id !== id));
  };

  if (!list) return <p>Loading…</p>;
  const shown = filter ? list.filter((e) => e.status === filter) : list;
  const counts = STATUSES.reduce((a, s) => ({ ...a, [s]: list.filter((e) => e.status === s).length }), {});

  return (
    <>
      <div className="admin-head"><h1>Enquiries</h1><button className="btn btn-outline btn-sm" onClick={load}>Refresh</button></div>
      <div className="stat-row">
        <button className={!filter ? 'active' : ''} onClick={() => setFilter('')}><strong>{list.length}</strong>All</button>
        {STATUSES.map((s) => <button key={s} className={filter === s ? 'active' : ''} onClick={() => setFilter(s)}><strong>{counts[s]}</strong>{s}</button>)}
      </div>
      {shown.length === 0 && <p className="muted">No enquiries yet.</p>}
      <div className="enq-list">
        {shown.map((e) => (
          <div key={e.id} className={`enq ${open === e.id ? 'open' : ''}`}>
            <button className="enq-top" onClick={() => setOpen(open === e.id ? null : e.id)}>
              <span className={`status s-${e.status}`}>{e.status}</span>
              <strong>{e.name}</strong>
              <span className="muted">{e.company}</span>
              <span className="tag">{e.type === 'bulk' ? 'Bulk' : `${e.items.length} item${e.items.length === 1 ? '' : 's'}`}</span>
              <span className="muted right">{new Date(e.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</span>
            </button>
            {open === e.id && (
              <div className="enq-body">
                <div className="enq-meta">
                  <a href={`tel:${e.phone}`}><Icon name="phone" size={15} /> {e.phone}</a>
                  <a href={`https://wa.me/91${e.phone.replace(/\D/g, '').slice(-10)}?text=${encodeURIComponent(`Hi ${e.name}, thanks for your enquiry ${e.id} with lastminutegifting!`)}`} target="_blank" rel="noreferrer">WhatsApp</a>
                  {e.email && <a href={`mailto:${e.email}`}><Icon name="mail" size={15} /> {e.email}</a>}
                  <span>{e.id} · {e.city}{e.deliveryDate && ` · needed by ${e.deliveryDate}`}{e.quantity && ` · qty ${e.quantity}`}{e.budget && ` · ${e.budget}`}</span>
                </div>
                {e.items.length > 0 && (
                  <table className="table">
                    <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Personalisation</th><th>Total</th></tr></thead>
                    <tbody>{e.items.map((i) => <tr key={i.id}><td>{i.name} <small className="muted">{i.sku}</small></td><td>{i.qty}</td><td>{inr(i.price)}</td><td>{i.branding || '—'}</td><td>{inr(i.lineTotal)}</td></tr>)}</tbody>
                    <tfoot><tr><td colSpan={4}>Estimated total</td><td>{inr(e.estimatedTotal)}</td></tr></tfoot>
                  </table>
                )}
                {e.message && <p className="enq-msg">{e.message}</p>}
                <div className="row-gap">
                  <select value={e.status} onChange={(ev) => setStatus(e.id, ev.target.value)}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
                  <button className="btn btn-outline btn-sm danger" onClick={() => remove(e.id)}>Delete</button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </>
  );
}

/* ---------------- Products ---------------- */
const blank = { name: '', sku: '', category: '', subcategory: '', price: '', mrp: '', moq: 1, description: '', features: [], branding: [], occasions: [], images: [], inStock: true, featured: false, bestseller: false, newArrival: false, sameDay: true, bulkNote: 'Special pricing from 50+ units' };

function Products({ token }) {
  const { catalog } = useStore();
  const [items, setItems] = useState(null);
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [editing, setEditing] = useState(null);
  const load = () => api.products({ limit: 100, sort: 'name' }).then(async (r) => {
    let all = r.items;
    for (let p = 2; p <= r.pages; p++) all = all.concat((await api.products({ limit: 100, sort: 'name', page: p })).items);
    setItems(all);
  });
  useEffect(() => { load(); }, []);

  const shown = useMemo(() => (items || []).filter((p) => (!cat || p.category === cat) && (!q || `${p.name} ${p.sku}`.toLowerCase().includes(q.toLowerCase()))), [items, q, cat]);

  const quickPrice = async (p, price) => {
    const n = Number(price);
    if (!n || n === p.price) return;
    const u = await api.admin.updateProduct(token, p.id, { price: n });
    setItems((l) => l.map((x) => (x.id === p.id ? u : x)));
  };

  if (editing) return <ProductEditor token={token} product={editing} catalog={catalog} onClose={(saved) => { setEditing(null); if (saved) load(); }} />;

  return (
    <>
      <div className="admin-head">
        <h1>Products <span className="muted">({items?.length ?? '…'})</span></h1>
        <button className="btn btn-primary btn-sm" onClick={() => setEditing({ ...blank, category: catalog.categories?.[0]?.slug || '' })}><Icon name="plus" size={16} /> Add product</button>
      </div>
      <div className="admin-filters">
        <input placeholder="Search name or SKU" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={cat} onChange={(e) => setCat(e.target.value)}>
          <option value="">All categories</option>
          {catalog.categories?.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
        </select>
      </div>
      <div className="table-wrap">
        <table className="table products-table">
          <thead><tr><th></th><th>Product</th><th>Category</th><th>Price (₹)</th><th>MRP</th><th>Photos</th><th></th></tr></thead>
          <tbody>
            {shown.map((p) => (
              <tr key={p.id}>
                <td className="thumb"><ProductImage product={p} /></td>
                <td><strong>{p.name}</strong><br /><small className="muted">{p.sku}{!p.inStock && ' · out of stock'}</small></td>
                <td>{catalog.categories?.find((c) => c.slug === p.category)?.name || p.category}<br /><small className="muted">{p.subcategory}</small></td>
                <td><input className="price-input" type="number" defaultValue={p.price} onBlur={(e) => quickPrice(p, e.target.value)} onKeyDown={(e) => e.key === 'Enter' && e.target.blur()} aria-label={`Price of ${p.name}`} /></td>
                <td>{inr(p.mrp)}</td>
                <td>{p.images?.length ? p.images.length : <span className="warn">none</span>}</td>
                <td><button className="btn btn-outline btn-sm" onClick={() => setEditing(p)}>Edit</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function ProductEditor({ token, product, catalog, onClose }) {
  const [p, setP] = useState({ ...product, features: (product.features || []).join('\n'), branding: (product.branding || []).join(', ') });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k) => (e) => setP({ ...p, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const cat = catalog.categories?.find((c) => c.slug === p.category);

  const upload = async (files) => {
    if (!files.length) return;
    setBusy(true);
    try {
      const { urls } = await api.admin.upload(token, files);
      setP((x) => ({ ...x, images: [...(x.images || []), ...urls] }));
    } catch { setErr('Upload failed (JPG/PNG/WebP, max 5 MB each)'); }
    setBusy(false);
  };
  const moveImg = (i, d) => setP((x) => { const a = [...x.images]; [a[i], a[i + d]] = [a[i + d], a[i]]; return { ...x, images: a }; });
  const toggleOcc = (s) => setP((x) => ({ ...x, occasions: x.occasions.includes(s) ? x.occasions.filter((o) => o !== s) : [...x.occasions, s] }));

  const save = async (e) => {
    e.preventDefault();
    setBusy(true); setErr('');
    const body = { ...p, features: p.features.split('\n').map((s) => s.trim()).filter(Boolean), branding: p.branding.split(',').map((s) => s.trim()).filter(Boolean) };
    try {
      product.id ? await api.admin.updateProduct(token, product.id, body) : await api.admin.createProduct(token, body);
      onClose(true);
    } catch (ex) { setErr(ex.message); setBusy(false); }
  };
  const del = async () => {
    if (!confirm(`Delete ${product.name}?`)) return;
    await api.admin.deleteProduct(token, product.id);
    onClose(true);
  };

  return (
    <form className="editor" onSubmit={save}>
      <div className="admin-head">
        <h1>{product.id ? 'Edit product' : 'New product'}</h1>
        <div className="row-gap">
          <button type="button" className="btn btn-outline btn-sm" onClick={() => onClose(false)}>Cancel</button>
          <button className="btn btn-primary btn-sm" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button>
        </div>
      </div>
      {err && <p className="err-box">{err}</p>}
      <div className="editor-grid">
        <div className="card form">
          <label className="field"><span>Name</span><input value={p.name} onChange={set('name')} required /></label>
          <div className="form-grid">
            <label className="field"><span>SKU / catalogue code</span><input value={p.sku} onChange={set('sku')} placeholder="auto if empty" /></label>
            <label className="field"><span>Category</span>
              <select value={p.category} onChange={(e) => setP({ ...p, category: e.target.value, subcategory: '' })}>{catalog.categories?.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select>
            </label>
            <label className="field"><span>Sub-category</span>
              <select value={p.subcategory} onChange={set('subcategory')}><option value="">—</option>{cat?.subcategories.map((s) => <option key={s}>{s}</option>)}</select>
            </label>
            <label className="field"><span>Min. order qty</span><input type="number" min="1" value={p.moq} onChange={set('moq')} /></label>
            <label className="field"><span>Selling price (₹)</span><input type="number" value={p.price} onChange={set('price')} required /></label>
            <label className="field"><span>MRP (₹, for strike-through)</span><input type="number" value={p.mrp} onChange={set('mrp')} /></label>
          </div>
          <label className="field"><span>Description</span><textarea rows={4} value={p.description} onChange={set('description')} /></label>
          <label className="field"><span>Key features (one per line)</span><textarea rows={4} value={p.features} onChange={set('features')} /></label>
          <label className="field"><span>Personalisation options (comma separated)</span><input value={p.branding} onChange={set('branding')} placeholder="Laser engraving, UV logo print" /></label>
          <label className="field"><span>Bulk note</span><input value={p.bulkNote} onChange={set('bulkNote')} /></label>
        </div>

        <div className="stack">
          <div className="card">
            <h3>Photos</h3>
            <div className="img-grid">
              {(p.images || []).map((src, i) => (
                <div key={src} className="img-cell">
                  <ProductImage product={{ ...p, images: [src] }} />
                  <div className="img-tools">
                    {i > 0 && <button type="button" onClick={() => moveImg(i, -1)} title="Move left">←</button>}
                    {i < p.images.length - 1 && <button type="button" onClick={() => moveImg(i, 1)} title="Move right">→</button>}
                    <button type="button" onClick={() => setP({ ...p, images: p.images.filter((x) => x !== src) })} title="Remove">✕</button>
                  </div>
                  {i === 0 && <span className="cover">Cover</span>}
                </div>
              ))}
              <label className="img-add">
                <input type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={(e) => upload(e.target.files)} hidden />
                <Icon name="plus" size={22} /><span>{busy ? 'Uploading…' : 'Add photos'}</span>
              </label>
            </div>
          </div>
          <div className="card">
            <h3>Visibility</h3>
            {[['inStock', 'In stock'], ['sameDay', 'Same-day delivery'], ['featured', 'Featured'], ['bestseller', 'Bestseller'], ['newArrival', 'New arrival']].map(([k, l]) => (
              <label key={k} className="check"><input type="checkbox" checked={!!p[k]} onChange={set(k)} /> {l}</label>
            ))}
          </div>
          <div className="card">
            <h3>Occasions</h3>
            <div className="pill-select">
              {catalog.occasions?.map((o) => <button type="button" key={o.slug} className={p.occasions?.includes(o.slug) ? 'on' : ''} onClick={() => toggleOcc(o.slug)}>{o.name}</button>)}
            </div>
          </div>
          {product.id && <button type="button" className="btn btn-outline danger" onClick={del}>Delete product</button>}
        </div>
      </div>
    </form>
  );
}

/* ---------------- Settings ---------------- */
function Settings({ token }) {
  const { settings } = useStore();
  const [s, setS] = useState(settings);
  const [saved, setSaved] = useState(false);
  useEffect(() => setS(settings), [settings]);
  if (!s) return null;
  const on = (k) => (e) => { setSaved(false); setS({ ...s, [k]: e.target.value }); };
  const save = async (e) => { e.preventDefault(); await api.admin.saveSettings(token, s); setSaved(true); };
  return (
    <form className="card form settings-form" onSubmit={save}>
      <h1>Store settings</h1>
      <div className="form-grid">
        <label className="field"><span>Phone (shown on site)</span><input value={s.phone || ''} onChange={on('phone')} /></label>
        <label className="field"><span>WhatsApp number (country code, no +)</span><input value={s.whatsapp || ''} onChange={on('whatsapp')} placeholder="919876543210" /></label>
        <label className="field"><span>Email</span><input value={s.email || ''} onChange={on('email')} /></label>
        <label className="field"><span>Address</span><input value={s.address || ''} onChange={on('address')} /></label>
      </div>
      <label className="field"><span>Tagline</span><input value={s.tagline || ''} onChange={on('tagline')} /></label>
      <label className="field"><span>Announcement bar</span><input value={s.announcement || ''} onChange={on('announcement')} /></label>
      <div className="field"><span>Delivery cities (tick to open a city)</span>
        <div className="row-gap">
          {s.cities?.map((c, i) => (
            <label key={c.slug} className="check"><input type="checkbox" checked={c.active} onChange={(e) => { setSaved(false); setS({ ...s, cities: s.cities.map((x, j) => (j === i ? { ...x, active: e.target.checked } : x)) }); }} /> {c.name}</label>
          ))}
        </div>
      </div>
      <button className="btn btn-primary">Save settings</button>
      {saved && <p className="hint good"><Icon name="check" size={14} /> Saved — reload the store to see changes.</p>}
    </form>
  );
}
