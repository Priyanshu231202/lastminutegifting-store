import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../components/Icon';
import { Field } from './Checkout';
import { api, imgUrl } from '../api';
import { useStore } from '../store';

// Trophies & awards are made to order, so this page shows the range and takes a quote request.
const types = [
  { name: 'Acrylic Trophies', text: 'Crystal-clear acrylic in star, wave and custom shapes with full-colour printing.', img: null, glyph: 'acrylic' },
  { name: 'Glass & Crystal Trophies', text: 'Premium glass awards with laser etching for leadership and milestone recognition.', img: null, glyph: 'glass' },
  { name: 'Metal & Wooden Trophies', text: 'Gold-finish metal tops on wooden bases — stars, cups, globes and figures.', img: '/uploads/catalogue/tro-cup.jpg' },
  { name: 'Momentos & Plaques', text: 'Wooden and metal plaques, certificate frames and desk momentos with your logo.', img: null, glyph: 'plaque' },
  { name: 'Medals', text: 'Zinc-alloy medals in gold, silver and bronze with custom ribbons — for sports days and events.', img: '/uploads/catalogue/tro-medals.jpg' },
  { name: 'Star & Achievement Awards', text: 'Framed star and figure awards for sales leaders, star performers and annual days.', img: '/uploads/catalogue/tro-star.jpg' },
];

const glyphs = {
  acrylic: <path d="M34 80h32M40 80l4-14h12l4 14M50 66V56M30 20c0 22 8 36 20 36s20-14 20-36z" />,
  glass: <path d="M30 82h40M38 82l2-10h20l2 10M50 72V18l14 22-14 32-14-32z" />,
  plaque: <><rect x="24" y="18" width="52" height="64" rx="4" /><rect x="34" y="30" width="32" height="22" rx="2" /><path d="M36 62h28M40 70h20" /></>,
};

export default function Trophies() {
  const { city } = useStore();
  const navigate = useNavigate();
  const [f, setF] = useState({ name: '', phone: '', email: '', company: '', quantity: '', budget: '', deliveryDate: '', kinds: [], message: '' });
  const [errors, setErrors] = useState({});
  const [sending, setSending] = useState(false);
  const [failed, setFailed] = useState('');
  const on = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const toggle = (n) => setF({ ...f, kinds: f.kinds.includes(n) ? f.kinds.filter((x) => x !== n) : [...f.kinds, n] });

  const submit = async (e) => {
    e.preventDefault();
    setSending(true); setFailed('');
    try {
      const message = [`TROPHIES & AWARDS enquiry`, f.kinds.length ? `Types: ${f.kinds.join(', ')}` : '', f.message].filter(Boolean).join('\n');
      const r = await api.enquire({ ...f, message, city: city || 'delhi', type: 'bulk', items: [] });
      navigate('/thank-you', { state: { id: r.id, name: f.name, bulk: true } });
    } catch (err) {
      if (err.data?.errors) setErrors(err.data.errors);
      else setFailed('Could not send right now. Please try again or WhatsApp us.');
    } finally { setSending(false); }
  };

  return (
    <div className="trophies">
      <section className="tro-hero container">
        <div className="tro-hero-copy">
          <span className="kicker dark"><Icon name="star" size={15} /> Trophies · Awards · Medals</span>
          <h1>Recognition that looks the part.</h1>
          <p className="muted">Custom trophies, plaques and medals for annual days, sales awards, sports events and client milestones — designed with your logo, names and citations.</p>
          <ul className="bulk-list">
            <li><Icon name="check" size={18} /> Free design proof before production</li>
            <li><Icon name="check" size={18} /> Names, logos & citations printed or etched</li>
            <li><Icon name="check" size={18} /> Any quantity — from 1 award to 1,000 medals</li>
          </ul>
          <a href="#quote" className="btn btn-primary btn-lg">Get a trophy quote <Icon name="chevron" size={18} /></a>
        </div>
        <div className="tro-hero-img"><img src={imgUrl('/uploads/catalogue/tro-hero.jpg')} alt="Gold trophy on a wooden base" /></div>
      </section>

      <section className="section container">
        <div className="section-head"><div><h2>What we make</h2><p className="muted">Ask for the full catalogue on WhatsApp — 150+ designs with sizes.</p></div></div>
        <div className="tro-grid">
          {types.map((t) => (
            <button key={t.name} type="button" className={`tro-card ${f.kinds.includes(t.name) ? 'on' : ''}`} onClick={() => { if (!f.kinds.includes(t.name)) toggle(t.name); document.getElementById('quote')?.scrollIntoView({ behavior: 'smooth' }); }}>
              <div className="tro-img">
                {t.img ? <img src={imgUrl(t.img)} alt={t.name} loading="lazy" /> : (
                  <div className="pimg placeholder" style={{ '--ph-bg': '#6b3f22', '--ph-fg': '#f2c46b' }}>
                    <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">{glyphs[t.glyph]}</svg>
                  </div>
                )}
              </div>
              <div className="tro-body"><strong>{t.name}</strong><span>{t.text}</span><em>Request quote →</em></div>
            </button>
          ))}
        </div>
      </section>

      <section className="container tro-quote" id="quote">
        <form className="card form" onSubmit={submit} noValidate>
          <h2>Tell us about your awards</h2>
          <div className="field">
            <span>What do you need?</span>
            <div className="pill-select">{types.map((t) => <button type="button" key={t.name} className={f.kinds.includes(t.name) ? 'on' : ''} onClick={() => toggle(t.name)}>{t.name}</button>)}</div>
          </div>
          <div className="form-grid">
            <Field label="Your name" error={errors.name}><input value={f.name} onChange={on('name')} autoComplete="name" /></Field>
            <Field label="Mobile number" error={errors.phone}><input value={f.phone} onChange={on('phone')} inputMode="tel" autoComplete="tel" /></Field>
            <Field label="Email" optional error={errors.email}><input type="email" value={f.email} onChange={on('email')} autoComplete="email" /></Field>
            <Field label="Company / school / club" optional><input value={f.company} onChange={on('company')} autoComplete="organization" /></Field>
            <Field label="How many?"><input value={f.quantity} onChange={on('quantity')} placeholder="e.g. 12 trophies + 60 medals" /></Field>
            <Field label="Budget per award" optional>
              <select value={f.budget} onChange={on('budget')}>
                <option value="">Select</option>
                {['Under ₹500', '₹500–₹1,000', '₹1,000–₹2,500', '₹2,500–₹5,000', '₹5,000+'].map((b) => <option key={b}>{b}</option>)}
              </select>
            </Field>
            <Field label="Event date" optional><input type="date" value={f.deliveryDate} onChange={on('deliveryDate')} /></Field>
          </div>
          <Field label="Event, award titles, anything else" optional>
            <textarea rows={4} value={f.message} onChange={on('message')} placeholder="e.g. Annual day on 15 Dec — 10 'Star Performer' acrylic awards with names, 1 CEO award in glass" />
          </Field>
          {failed && <p className="err-box">{failed}</p>}
          <button className="btn btn-primary btn-lg block" disabled={sending}>{sending ? 'Sending…' : 'Get my quote'}</button>
        </form>
      </section>
    </div>
  );
}
