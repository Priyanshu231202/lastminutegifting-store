import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import ProductImage from '../components/ProductImage';
import ProductCard from '../components/ProductCard';
import Icon from '../components/Icon';
import { api, discount, inr } from '../api';
import { useStore } from '../store';

export default function Product() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { addToCart, settings, catalog } = useStore();
  const [data, setData] = useState(null);
  const [error, setError] = useState(false);
  const [img, setImg] = useState(0);
  const [qty, setQty] = useState(1);
  const [branding, setBranding] = useState('');
  const [brandText, setBrandText] = useState('');

  useEffect(() => {
    setData(null); setError(false); setImg(0); setBranding(''); setBrandText('');
    api.product(slug).then((d) => { setData(d); setQty(d.product.moq || 1); }).catch(() => setError(true));
  }, [slug]);

  if (error) return <div className="container empty-state"><h1>We couldn’t find that gift</h1><Link to="/collections/all" className="btn btn-primary">Browse all gifts</Link></div>;
  if (!data) return <div className="container pdp"><div className="pdp-grid"><div className="skeleton pdp-skel" /><div className="skeleton pdp-skel" /></div></div>;

  const p = data.product;
  const off = discount(p);
  const cat = catalog.categories?.find((c) => c.slug === p.category);
  const moq = p.moq || 1;
  const imgs = p.images?.length ? p.images : [null];
  const brandingValue = branding ? `${branding}${brandText ? `: ${brandText}` : ''}` : '';
  const waText = `Hi! I'm interested in ${p.name} (${p.sku}) × ${qty}${brandingValue ? `, with ${brandingValue}` : ''}. Can you deliver today?`;

  const add = (go) => {
    addToCart(p, qty, brandingValue);
    if (go) navigate('/cart');
  };

  return (
    <div className="container pdp">
      <nav className="crumbs">
        <Link to="/">Home</Link><Icon name="chevron" size={12} />
        {cat && <><Link to={`/collections/${cat.slug}`}>{cat.name}</Link><Icon name="chevron" size={12} /></>}
        <span>{p.name}</span>
      </nav>

      <div className="pdp-grid">
        <div className="gallery">
          <div className="gallery-main">
            <ProductImage product={p} index={img} />
            {off > 0 && <span className="badge sale big">{off}% off</span>}
          </div>
          {imgs.length > 1 && (
            <div className="thumbs">
              {imgs.map((_, i) => (
                <button key={i} className={i === img ? 'active' : ''} onClick={() => setImg(i)} aria-label={`Image ${i + 1}`}>
                  <ProductImage product={p} index={i} />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="pdp-info">
          <div className="pdp-tags">
            {p.bestseller && <span className="badge">Bestseller</span>}
            {p.newArrival && <span className="badge new">New</span>}
            {p.sameDay && <span className="badge bolt"><Icon name="bolt" size={12} /> Same-day in Delhi</span>}
          </div>
          <h1>{p.name}</h1>
          <p className="sku">SKU {p.sku}{p.subcategory ? ` · ${p.subcategory}` : ''}</p>
          <div className="pdp-price">
            <span className="price">{inr(p.price)}</span>
            {off > 0 && <><s className="mrp">{inr(p.mrp)}</s><span className="save">Save {inr(p.mrp - p.price)}</span></>}
          </div>
          <p className="tax">Inclusive of all taxes · per piece</p>

          {p.branding?.length > 0 && (
            <div className="field">
              <label htmlFor="branding">Personalise it <span className="muted">(optional)</span></label>
              <select id="branding" value={branding} onChange={(e) => setBranding(e.target.value)}>
                <option value="">No personalisation</option>
                {p.branding.map((b) => <option key={b}>{b}</option>)}
              </select>
              {branding && (
                <input value={brandText} onChange={(e) => setBrandText(e.target.value)} maxLength={60}
                  placeholder={/logo/i.test(branding) ? 'Company name (we’ll ask for the logo file)' : 'Name or text to add'} />
              )}
            </div>
          )}

          <div className="field">
            <label>Quantity {moq > 1 && <span className="muted">(min. {moq})</span>}</label>
            <div className="qty-row">
              <div className="qty">
                <button onClick={() => setQty((q) => Math.max(moq, q - 1))} aria-label="Decrease"><Icon name="minus" size={16} /></button>
                <input type="number" min={moq} value={qty} onChange={(e) => setQty(Math.max(moq, parseInt(e.target.value) || moq))} aria-label="Quantity" />
                <button onClick={() => setQty((q) => q + 1)} aria-label="Increase"><Icon name="plus" size={16} /></button>
              </div>
              <span className="line-total">= {inr(qty * p.price)}</span>
            </div>
            {qty >= Math.max(50, moq * 2) && <p className="hint good"><Icon name="check" size={14} /> {qty}+ pieces qualifies for bulk pricing — we’ll quote a better rate.</p>}
          </div>

          <div className="pdp-actions">
            <button className="btn btn-primary btn-lg" onClick={() => add(false)} disabled={!p.inStock}>{p.inStock ? 'Add to gift list' : 'Out of stock'}</button>
            <button className="btn btn-dark btn-lg" onClick={() => add(true)} disabled={!p.inStock}>Enquire now</button>
          </div>
          {settings?.whatsapp && (
            <a className="wa-line" href={`https://wa.me/${settings.whatsapp}?text=${encodeURIComponent(waText)}`} target="_blank" rel="noreferrer">
              Need it urgently? Chat on WhatsApp <Icon name="chevron" size={14} />
            </a>
          )}

          <ul className="assure">
            <li><Icon name="bolt" size={18} /> {p.sameDay ? 'Delivered in 2–4 hours across Delhi' : 'Delivered in 1–2 days across Delhi'}</li>
            <li><Icon name="gift" size={18} /> Free gift wrap & message card</li>
            <li><Icon name="building" size={18} /> {p.bulkNote || 'Bulk pricing available'} — <Link to="/bulk-enquiry">get a quote</Link></li>
          </ul>

          <div className="pdp-desc">
            <h3>About this gift</h3>
            <p>{p.description}</p>
            {p.features?.length > 0 && <ul className="features">{p.features.map((f) => <li key={f}><Icon name="check" size={14} /> {f}</li>)}</ul>}
          </div>
        </div>
      </div>

      {data.related.length > 0 && (
        <section className="section">
          <div className="section-head"><h2>You may also like</h2></div>
          <div className="rail">{data.related.map((r) => <ProductCard key={r.id} product={r} />)}</div>
        </section>
      )}
    </div>
  );
}
