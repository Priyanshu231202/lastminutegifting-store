import { Link, useParams } from 'react-router-dom';
import NotFound from './NotFound';

// Simple content pages. Edit the text here to match your real policies.
const pages = {
  about: {
    title: 'About lastminutegifting',
    body: [
      'We started lastminutegifting for everyone who remembers the birthday on the day of the birthday. We keep a ready stock of premium gifts in Delhi so we can pack, personalise and deliver in 2–4 hours.',
      'Our range covers premium pens and stationery, drinkware, bags, wall clocks and décor, eco-friendly gifts, tech accessories and curated gift sets. We also work with companies on bulk and branded gifting for employees, clients and events.',
      'We’re launching in Noida, Gurugram and Chandigarh soon.',
    ],
  },
  faq: {
    title: 'Frequently asked questions',
    qa: [
      ['Which areas do you deliver to?', 'All of Delhi today. Noida, Gurugram and Chandigarh are coming soon. Bulk orders can ship anywhere in India.'],
      ['What are your delivery timings?', 'Same-day items reach within 2–4 hours. Orders confirmed by 8 PM are delivered the same day.'],
      ['How do I pay?', 'After you send an enquiry, we confirm the details and share a secure payment link (UPI, cards, net banking).'],
      ['Can I add a message?', 'Yes — every gift gets a free message card. Add the message in the enquiry form.'],
      ['Do you give GST invoices?', 'Yes, for all orders. Share your GSTIN when we call to confirm.'],
    ],
  },
  shipping: {
    title: 'Delivery policy',
    body: [
      'Same-day delivery is available across Delhi for products marked “Same-day”. Orders confirmed by 8 PM are delivered within 2–4 hours.',
      'Personalised and bulk orders need 1–7 working days depending on quantity and branding method; we’ll confirm the timeline in your quote.',
      'Delivery charges, if any, are confirmed on call before payment.',
    ],
  },
  refunds: {
    title: 'Returns & refunds',
    body: [
      'If a gift arrives damaged or incorrect, message us within 24 hours with a photo and we’ll replace it at no cost.',
      'Personalised or branded products cannot be returned unless they are defective.',
      'Refunds, where applicable, are processed to the original payment method within 5–7 working days.',
    ],
  },
  terms: {
    title: 'Terms & privacy',
    body: [
      'Prices shown are estimates until confirmed by our team. Product photos are representative; finishes may vary slightly.',
      'We collect your name, phone number and email only to process your enquiry and order. We do not sell or share your details.',
    ],
  },
};

export default function InfoPage() {
  const { page } = useParams();
  const p = pages[page];
  if (!p) return <NotFound />;
  return (
    <div className="container narrow info-page">
      <h1>{p.title}</h1>
      {p.body?.map((t) => <p key={t}>{t}</p>)}
      {p.qa && <div className="faq">{p.qa.map(([q, a]) => <details key={q} open><summary>{q}</summary><p>{a}</p></details>)}</div>}
      <p className="muted">Still have a question? <Link to="/bulk-enquiry">Write to us</Link>.</p>
    </div>
  );
}
