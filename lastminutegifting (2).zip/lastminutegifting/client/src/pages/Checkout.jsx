import { useRef, useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import ProductImage from '../components/ProductImage';
import Icon from '../components/Icon';
import { api, inr } from '../api';
import { useStore } from '../store';

export function Field({ label, error, children, optional }) {
  return (
    <label className={`field ${error ? 'has-error' : ''}`}>
      <span>{label}{optional && <em> (optional)</em>}</span>
      {children}
      {error && <small className="err">{error}</small>}
    </label>
  );
}

const today = () => new Date().toISOString().slice(0, 10);

export default function Checkout() {
  const { cart, cartTotal, city, clearCart } = useStore();
  const navigate = useNavigate();
  const [f, setF] = useState({ name: '', phone: '', email: '', company: '', deliveryDate: today(), message: '' });
  const [errors, setErrors] = useState({});
  const [sending, setSending] = useState(false);
  const [failed, setFailed] = useState('');
  const done = useRef(false);
  const on = (k) => (e) => setF({ ...f, [k]: e.target.value });

  if (!cart.length && !done.current) return <Navigate to="/cart" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setSending(true); setFailed('');
    try {
      const r = await api.enquire({ ...f, city, type: 'cart', items: cart.map((i) => ({ id: i.id, qty: i.qty, branding: i.branding })) });
      done.current = true;
      navigate('/thank-you', { state: { id: r.id, name: f.name, total: r.estimatedTotal } });
      clearCart();
    } catch (err) {
      if (err.data?.errors) setErrors(err.data.errors);
      else setFailed('Could not send right now. Please try again or WhatsApp us.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="container checkout">
      <nav className="crumbs"><Link to="/cart">Gift list</Link><Icon name="chevron" size={12} /><span>Your details</span></nav>
      <h1>Almost done — where do we reach you?</h1>
      <div className="cart-layout">
        <form className="card form" onSubmit={submit} noValidate>
          <div className="form-grid">
            <Field label="Full name" error={errors.name}><input value={f.name} onChange={on('name')} autoComplete="name" required /></Field>
            <Field label="Mobile number" error={errors.phone}><input value={f.phone} onChange={on('phone')} inputMode="tel" autoComplete="tel" placeholder="10-digit mobile" required /></Field>
            <Field label="Email" optional error={errors.email}><input type="email" value={f.email} onChange={on('email')} autoComplete="email" /></Field>
            <Field label="Company" optional><input value={f.company} onChange={on('company')} autoComplete="organization" /></Field>
            <Field label="Needed by"><input type="date" min={today()} value={f.deliveryDate} onChange={on('deliveryDate')} /></Field>
            <Field label="Delivery city"><input value={city ? city[0].toUpperCase() + city.slice(1) : 'Delhi'} disabled /></Field>
          </div>
          <Field label="Delivery area, gift message or anything else" optional>
            <textarea rows={4} value={f.message} onChange={on('message')} placeholder="e.g. Deliver to Saket by 6 PM, card should say “Happy birthday Riya!”" />
          </Field>
          {failed && <p className="err-box">{failed}</p>}
          <button className="btn btn-primary btn-lg block" disabled={sending}>{sending ? 'Sending…' : 'Send enquiry'}</button>
          <p className="fine"><Icon name="shield" size={14} /> We only use your number to confirm this order.</p>
        </form>

        <aside className="summary">
          <h3>Your gift list</h3>
          {cart.map((i) => (
            <div key={i.id} className="mini-item">
              <ProductImage product={i} />
              <div><strong>{i.name}</strong><span className="muted">× {i.qty}{i.branding ? ` · ${i.branding}` : ''}</span></div>
              <span>{inr(i.price * i.qty)}</span>
            </div>
          ))}
          <div className="sum-row total"><span>Estimated total</span><span>{inr(cartTotal)}</span></div>
        </aside>
      </div>
    </div>
  );
}
