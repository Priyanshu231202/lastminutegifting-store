import { useEffect, useMemo, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import Icon from '../components/Icon';
import { api } from '../api';
import { useStore } from '../store';

const slugify = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
const specials = {
  all: { title: 'All Gifts', blurb: 'Every gift we stock, ready to deliver.', params: {} },
  bestsellers: { title: 'Bestsellers', blurb: 'What Delhi gifts the most.', params: { flag: 'bestseller' } },
  new: { title: 'New Arrivals', blurb: 'Fresh additions to the range.', params: { flag: 'newArrival', sort: 'newest' } },
  'same-day': { title: 'Same-Day Delivery', blurb: 'Order till 8 PM, delivered in 2–4 hours across Delhi.', params: { sameDay: '1' } },
};
const priceBands = [
  ['Under ₹500', '', 499], ['₹500 – ₹1,000', 500, 1000], ['₹1,000 – ₹2,000', 1000, 2000], ['Above ₹2,000', 2000, ''],
];

export default function Collection({ search }) {
  const { slug } = useParams();
  const [sp, setSp] = useSearchParams();
  const { catalog } = useStore();
  const [data, setData] = useState({ items: [], total: 0, pages: 1 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  const q = sp.get('q') || '';
  const sub = sp.get('sub') || '';
  const sort = sp.get('sort') || '';
  const band = sp.get('price') || '';
  const sameDayOnly = sp.get('sd') === '1';

  const category = catalog.categories?.find((c) => c.slug === slug);
  const occasion = catalog.occasions?.find((o) => o.slug === slug);
  const meta = search
    ? { title: `Results for “${q}”`, blurb: '', params: { q } }
    : category ? { title: category.name, blurb: category.blurb, params: { category: slug } }
    : occasion ? { title: `${occasion.name} Gifts`, blurb: `Hand-picked gifts for ${occasion.name.toLowerCase()}.`, params: { occasion: slug } }
    : specials[slug] || (catalog.categories?.length ? null : { title: '', params: {} });

  const params = useMemo(() => {
    if (!meta) return null;
    const [, min, max] = priceBands.find((b) => b[0] === band) || [];
    return { ...meta.params, sub, sort: sort || meta.params.sort, min, max, sameDay: sameDayOnly ? '1' : meta.params.sameDay, limit: 24 };
  }, [JSON.stringify(meta?.params), sub, sort, band, sameDayOnly]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { setPage(1); }, [params]);
  useEffect(() => {
    if (!params || (!search && !catalog.categories?.length)) return;
    setLoading(true);
    api.products({ ...params, page }).then((r) => {
      setData((d) => (page === 1 ? r : { ...r, items: [...d.items, ...r.items] }));
    }).finally(() => setLoading(false));
  }, [params, page, catalog.categories?.length, search]);

  const set = (k, v) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); setSp(n, { replace: true }); };

  if (!meta) return <div className="container empty-state"><h1>Collection not found</h1><Link to="/collections/all" className="btn btn-primary">Browse all gifts</Link></div>;

  const activeCount = [sub, band, sameDayOnly].filter(Boolean).length;
  return (
    <div className="container collection">
      <nav className="crumbs"><Link to="/">Home</Link><Icon name="chevron" size={12} /><span>{search ? 'Search' : meta.title}</span></nav>
      <header className="coll-head">
        <h1>{meta.title}</h1>
        {meta.blurb && <p className="muted">{meta.blurb}</p>}
      </header>

      <div className="coll-layout">
        <aside className={`filters ${showFilters ? 'open' : ''}`}>
          <div className="filters-head only-mobile"><strong>Filters</strong><button className="icon-btn" onClick={() => setShowFilters(false)}><Icon name="close" /></button></div>
          {category && category.subcategories?.length > 0 && (
            <div className="fgroup">
              <h4>Type</h4>
              <label className="radio"><input type="radio" checked={!sub} onChange={() => set('sub', '')} /> All {category.name}</label>
              {category.subcategories.map((s) => (
                <label key={s} className="radio"><input type="radio" checked={sub === slugify(s)} onChange={() => set('sub', slugify(s))} /> {s}</label>
              ))}
            </div>
          )}
          {!category && !search && (
            <div className="fgroup">
              <h4>Category</h4>
              {catalog.categories?.map((c) => <Link key={c.slug} to={`/collections/${c.slug}`} className="flink">{c.name}</Link>)}
            </div>
          )}
          <div className="fgroup">
            <h4>Price</h4>
            <label className="radio"><input type="radio" checked={!band} onChange={() => set('price', '')} /> Any price</label>
            {priceBands.map(([l]) => <label key={l} className="radio"><input type="radio" checked={band === l} onChange={() => set('price', l)} /> {l}</label>)}
          </div>
          {slug !== 'same-day' && (
            <div className="fgroup">
              <h4>Delivery</h4>
              <label className="check"><input type="checkbox" checked={sameDayOnly} onChange={(e) => set('sd', e.target.checked ? '1' : '')} /> Same-day available</label>
            </div>
          )}
          {activeCount > 0 && <button className="btn btn-outline btn-sm" onClick={() => setSp(q ? { q } : {}, { replace: true })}>Clear filters</button>}
          <button className="btn btn-primary only-mobile" onClick={() => setShowFilters(false)}>Show {data.total} gifts</button>
        </aside>

        <section>
          <div className="toolbar">
            <button className="btn btn-outline btn-sm only-mobile" onClick={() => setShowFilters(true)}><Icon name="filter" size={16} /> Filters{activeCount ? ` (${activeCount})` : ''}</button>
            <span className="muted">{loading && page === 1 ? 'Loading…' : `${data.total} gift${data.total === 1 ? '' : 's'}`}</span>
            <select value={sort} onChange={(e) => set('sort', e.target.value)} aria-label="Sort by">
              <option value="">Sort: Featured</option>
              <option value="price-asc">Price: Low to high</option>
              <option value="price-desc">Price: High to low</option>
              <option value="newest">Newest</option>
              <option value="name">Name A–Z</option>
            </select>
          </div>

          {!loading && data.total === 0 ? (
            <div className="empty-state">
              <Icon name="search" size={40} />
              <h3>No gifts match that</h3>
              <p className="muted">Try another filter — or tell us what you need and we’ll source it.</p>
              <Link to="/bulk-enquiry" className="btn btn-primary">Ask our gifting team</Link>
            </div>
          ) : (
            <div className="grid">
              {data.items.map((p) => <ProductCard key={p.id} product={p} />)}
              {loading && Array.from({ length: 4 }).map((_, i) => <div key={i} className="pcard skeleton" />)}
            </div>
          )}
          {page < data.pages && !loading && (
            <div className="center"><button className="btn btn-outline" onClick={() => setPage((p) => p + 1)}>Load more gifts</button></div>
          )}
        </section>
      </div>
    </div>
  );
}
