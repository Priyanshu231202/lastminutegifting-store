import { Link, useLocation } from 'react-router-dom';
import Icon from '../components/Icon';
import { inr } from '../api';
import { useStore } from '../store';

export default function ThankYou() {
  const { state } = useLocation();
  const { settings } = useStore();
  const wa = settings?.whatsapp;
  return (
    <div className="container empty-state thanks">
      <span className="tick"><Icon name="check" size={36} stroke={2.5} /></span>
      <h1>Thank you{state?.name ? `, ${state.name.split(' ')[0]}` : ''}!</h1>
      <p>Your enquiry {state?.id && <strong>{state.id}</strong>} is with our gifting team.</p>
      <p className="muted">
        {state?.bulk
          ? 'We’ll send curated options and bulk pricing within 24 hours.'
          : `We’ll call or WhatsApp you within 15 minutes to confirm${state?.total ? ` (estimate ${inr(state.total)})` : ''} and share a payment link.`}
      </p>
      <div className="row-gap">
        {wa && state?.id && (
          <a className="btn btn-dark" href={`https://wa.me/${wa}?text=${encodeURIComponent(`Hi! I just sent enquiry ${state.id}.`)}`} target="_blank" rel="noreferrer">Speed it up on WhatsApp</a>
        )}
        <Link to="/" className="btn btn-outline">Back to home</Link>
      </div>
    </div>
  );
}
