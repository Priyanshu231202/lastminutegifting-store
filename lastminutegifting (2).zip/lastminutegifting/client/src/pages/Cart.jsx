import { Link, useNavigate } from 'react-router-dom';
import ProductImage from '../components/ProductImage';
import Icon from '../components/Icon';
import { inr } from '../api';
import { useStore } from '../store';

export default function Cart() {
  const { cart, updateQty, updateBranding, removeFromCart, cartTotal, cartCount } = useStore();
  const navigate = useNavigate();

  if (!cart.length) {
    return (
      <div className="container empty-state">
        <Icon name="bag" size={44} />
        <h1>Your gift list is empty</h1>
        <p className="muted">Add a few gifts and send us one enquiry — we’ll confirm price and delivery in minutes.</p>
        <Link to="/collections/same-day" className="btn btn-primary">Shop same-day gifts</Link>
      </div>
    );
  }

  return (
    <div className="container cart-page">
      <h1>Your gift list <span className="muted">({cartCount} item{cartCount === 1 ? '' : 's'})</span></h1>
      <div className="cart-layout">
        <div className="cart-items">
          {cart.map((i) => (
            <div key={i.id} className="cart-item">
              <Link to={`/products/${i.slug}`} className="ci-img"><ProductImage product={i} /></Link>
              <div className="ci-body">
                <Link to={`/products/${i.slug}`} className="ci-name">{i.name}</Link>
                <span className="muted">{inr(i.price)} each{i.moq > 1 ? ` · min. ${i.moq}` : ''}</span>
                <input className="ci-brand" value={i.branding} onChange={(e) => updateBranding(i.id, e.target.value)} placeholder="Personalisation (name / logo) — optional" maxLength={80} />
                <div className="ci-row">
                  <div className="qty small">
                    <button onClick={() => updateQty(i.id, i.qty - 1)} aria-label="Decrease"><Icon name="minus" size={14} /></button>
                    <input type="number" value={i.qty} min={i.moq} onChange={(e) => updateQty(i.id, parseInt(e.target.value) || 1)} aria-label="Quantity" />
                    <button onClick={() => updateQty(i.id, i.qty + 1)} aria-label="Increase"><Icon name="plus" size={14} /></button>
                  </div>
                  <strong>{inr(i.qty * i.price)}</strong>
                  <button className="icon-btn danger" onClick={() => removeFromCart(i.id)} aria-label={`Remove ${i.name}`}><Icon name="trash" size={18} /></button>
                </div>
              </div>
            </div>
          ))}
          <Link to="/collections/all" className="back-link">← Keep shopping</Link>
        </div>

        <aside className="summary">
          <h3>Estimate</h3>
          <div className="sum-row"><span>Items ({cartCount})</span><span>{inr(cartTotal)}</span></div>
          <div className="sum-row"><span>Gift wrap</span><span className="good">Free</span></div>
          <div className="sum-row"><span>Delivery</span><span>Confirmed on call</span></div>
          <div className="sum-row total"><span>Estimated total</span><span>{inr(cartTotal)}</span></div>
          {cartCount >= 50 && <p className="hint good"><Icon name="check" size={14} /> Bulk order — you’ll get a better rate in our quote.</p>}
          <button className="btn btn-primary btn-lg block" onClick={() => navigate('/checkout')}>Send enquiry</button>
          <p className="fine">No payment now. We confirm stock, final price and delivery slot by call/WhatsApp, then share a payment link.</p>
        </aside>
      </div>
    </div>
  );
}
