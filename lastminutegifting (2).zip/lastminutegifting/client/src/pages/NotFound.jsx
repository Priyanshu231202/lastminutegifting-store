import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="container empty-state">
      <h1>This page went to deliver a gift</h1>
      <p className="muted">…and hasn’t come back. Let’s find you something else.</p>
      <Link to="/" className="btn btn-primary">Go home</Link>
    </div>
  );
}
