import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../components/Icon';
import { Field } from './Checkout';
import { api } from '../api';
import { useStore } from '../store';

export default function BulkEnquiry() {
  const { catalog, city } = useStore();
  const navigate = useNavigate();
  const [f, setF] = useState({ name: '', phone: '', email: '', company: '', quantity: '', budget: '', deliveryDate: '', interests: [], message: '' });
  const [errors, setErrors] = useState({});
  const [sending, setSending] = useState(false);
  const [failed, setFailed] = useState('');
  const on = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const toggle = (name) => setF({ ...f, interests: f.interests.includes(name) ? f.interests.filter((x) => x !== name) : [...f.interests, name] });

  const submit = async (e) => {
    e.preventDefault();
    setSending(true); setFailed('');
    try {
      const message = [f.interests.length ? `Interested in: ${f.interests.join(', ')}` : '', f.message].filter(Boolean).join('\n');
      const r = await api.enquire({ ...f, message, city: city || 'delhi', type: 'bulk', items: [] });
      navigate('/thank-you', { state: { id: r.id, name: f.name, bulk: true } });
    } catch (err) {
      if (err.data?.errors) setErrors(err.data.errors);
      else setFailed('Could not send right now. Please try again or WhatsApp us.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="container bulk-page">
      <div className="bulk-intro">
        <span className="kicker dark"><Icon name="building" size={15} /> Bulk & corporate gifting</span>
        <h1>Gifts for your whole team, clients or event — with your logo.</h1>
        <p className="muted">Share a few details and our gifting team will send curated options, logo mock-ups and bulk pricing within 24 hours.</p>
        <ul className="bulk-list">
          <li><Icon name="check" size={18} /> Special pricing from 50 units</li>
          <li><Icon name="check" size={18} /> Laser engraving, UV print, embroidery</li>
          <li><Icon name="check" size={18} /> Custom packaging & message cards</li>
          <li><Icon name="check" size={18} /> Delivery to one office or 500 homes</li>
          <li><Icon name="check" size={18} /> GST invoice for your accounts team</li>
        </ul>
      </div>

      <form className="card form" onSubmit={submit} noValidate>
        <h2>Request a quote</h2>
        <div className="form-grid">
          <Field label="Your name" error={errors.name}><input value={f.name} onChange={on('name')} autoComplete="name" /></Field>
          <Field label="Mobile number" error={errors.phone}><input value={f.phone} onChange={on('phone')} inputMode="tel" autoComplete="tel" /></Field>
          <Field label="Work email" optional error={errors.email}><input type="email" value={f.email} onChange={on('email')} autoComplete="email" /></Field>
          <Field label="Company" optional><input value={f.company} onChange={on('company')} autoComplete="organization" /></Field>
          <Field label="Quantity">
            <select value={f.quantity} onChange={on('quantity')}>
              <option value="">Select</option>
              {['25–50', '50–100', '100–250', '250–500', '500+'].map((q) => <option key={q}>{q}</option>)}
            </select>
          </Field>
          <Field label="Budget per gift">
            <select value={f.budget} onChange={on('budget')}>
              <option value="">Select</option>
              {['Under ₹500', '₹500–₹1,000', '₹1,000–₹2,000', '₹2,000–₹5,000', '₹5,000+'].map((b) => <option key={b}>{b}</option>)}
            </select>
          </Field>
          <Field label="Needed by" optional><input type="date" value={f.deliveryDate} onChange={on('deliveryDate')} /></Field>
        </div>
        <div className="field">
          <span>What are you looking for? <em>(optional)</em></span>
          <div className="pill-select">
            {[...(catalog.categories || []).flatMap((c) => c.subcategories), 'Trophies & Awards', 'Medals', 'Something else'].map((n) => (
              <button type="button" key={n} className={f.interests.includes(n) ? 'on' : ''} onClick={() => toggle(n)}>{n}</button>
            ))}
          </div>
        </div>
        <Field label="Anything else?" optional>
          <textarea rows={4} value={f.message} onChange={on('message')} placeholder="Occasion, branding needs, delivery locations…" />
        </Field>
        {failed && <p className="err-box">{failed}</p>}
        <button className="btn btn-primary btn-lg block" disabled={sending}>{sending ? 'Sending…' : 'Get my quote'}</button>
      </form>
    </div>
  );
}
