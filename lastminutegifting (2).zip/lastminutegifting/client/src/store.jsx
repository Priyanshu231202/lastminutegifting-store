import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from './api';

const StoreCtx = createContext(null);
const safeGet = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const safeSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } };

export function StoreProvider({ children }) {
  const [settings, setSettings] = useState(null);
  const [catalog, setCatalog] = useState({ categories: [], occasions: [] });
  const [city, setCityState] = useState(() => safeGet('lmg_city', null));
  const [cart, setCart] = useState(() => safeGet('lmg_cart', []));
  const [toast, setToast] = useState(null);

  useEffect(() => {
    api.settings().then(setSettings).catch(() => setSettings({}));
    api.categories().then(setCatalog).catch(() => {});
  }, []);
  useEffect(() => safeSet('lmg_cart', cart), [cart]);

  const setCity = (c) => { setCityState(c); safeSet('lmg_city', c); };

  const showToast = useCallback((msg) => {
    setToast(msg);
    clearTimeout(window.__lmgToast);
    window.__lmgToast = setTimeout(() => setToast(null), 2600);
  }, []);

  // Cart = enquiry list. Item: { id, slug, name, price, image, qty, moq, branding }
  const addToCart = useCallback((p, qty = 1, branding = '') => {
    setCart((c) => {
      const found = c.find((i) => i.id === p.id);
      if (found) return c.map((i) => (i.id === p.id ? { ...i, qty: i.qty + qty, branding: branding || i.branding } : i));
      return [...c, { id: p.id, slug: p.slug, name: p.name, price: p.price, image: p.images?.[0] || null, category: p.category, moq: p.moq || 1, qty: Math.max(qty, p.moq || 1), branding }];
    });
    showToast(`Added “${p.name}” to your gift list`);
  }, [showToast]);

  const updateQty = (id, qty) => setCart((c) => c.map((i) => (i.id === id ? { ...i, qty: Math.max(i.moq || 1, qty) } : i)));
  const updateBranding = (id, branding) => setCart((c) => c.map((i) => (i.id === id ? { ...i, branding } : i)));
  const removeFromCart = (id) => setCart((c) => c.filter((i) => i.id !== id));
  const clearCart = () => setCart([]);

  const value = useMemo(() => ({
    settings, catalog, city, setCity, cart, addToCart, updateQty, updateBranding, removeFromCart, clearCart,
    cartCount: cart.reduce((s, i) => s + i.qty, 0),
    cartTotal: cart.reduce((s, i) => s + i.qty * i.price, 0),
    toast, showToast,
  }), [settings, catalog, city, cart, toast, addToCart, showToast]);

  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export const useStore = () => useContext(StoreCtx);
