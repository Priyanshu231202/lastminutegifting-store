// All calls to the Node API live here.
const BASE = import.meta.env.VITE_API_URL || '';

async function request(path, { method = 'GET', body, token, isForm } = {}) {
  const headers = {};
  if (!isForm && body) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(BASE + path, { method, headers, body: isForm ? body : body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed');
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

export const api = {
  settings: () => request('/api/settings'),
  categories: () => request('/api/categories'),
  products: (params = {}) => request('/api/products?' + new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null))),
  product: (slug) => request(`/api/products/${encodeURIComponent(slug)}`),
  enquire: (body) => request('/api/enquiries', { method: 'POST', body }),

  admin: {
    check: (t) => request('/api/admin/check', { token: t }),
    enquiries: (t) => request('/api/admin/enquiries', { token: t }),
    updateEnquiry: (t, id, body) => request(`/api/admin/enquiries/${id}`, { method: 'PATCH', body, token: t }),
    deleteEnquiry: (t, id) => request(`/api/admin/enquiries/${id}`, { method: 'DELETE', token: t }),
    createProduct: (t, body) => request('/api/admin/products', { method: 'POST', body, token: t }),
    updateProduct: (t, id, body) => request(`/api/admin/products/${id}`, { method: 'PUT', body, token: t }),
    deleteProduct: (t, id) => request(`/api/admin/products/${id}`, { method: 'DELETE', token: t }),
    upload: (t, files) => {
      const fd = new FormData();
      [...files].forEach((f) => fd.append('images', f));
      return request('/api/admin/upload', { method: 'POST', body: fd, token: t, isForm: true });
    },
    saveSettings: (t, body) => request('/api/admin/settings', { method: 'PUT', body, token: t }),
  },
};

export const inr = (n) => '₹' + Number(n || 0).toLocaleString('en-IN');
export const discount = (p) => (p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0);
export const imgUrl = (src) => (!src ? null : /^https?:/.test(src) ? src : BASE + src);
