import { Link } from 'react-router-dom';
import ProductImage from './ProductImage';
import Icon from './Icon';
import { discount, inr } from '../api';
import { useStore } from '../store';

export default function ProductCard({ product: p }) {
  const { addToCart } = useStore();
  const off = discount(p);
  return (
    <article className="pcard">
      <Link to={`/products/${p.slug}`} className="pcard-media">
        <ProductImage product={p} />
        {p.images?.[1] && <ProductImage product={p} index={1} className="hover-img" />}
        <div className="badges">
          {off > 0 && <span className="badge sale">{off}% off</span>}
          {p.bestseller && <span className="badge">Bestseller</span>}
          {!p.bestseller && p.newArrival && <span className="badge new">New</span>}
        </div>
        {p.sameDay && <span className="sameday"><Icon name="bolt" size={13} /> Same-day</span>}
      </Link>
      <div className="pcard-body">
        <Link to={`/products/${p.slug}`} className="pcard-title">{p.name}</Link>
        <div className="price-row">
          <span className="price">{inr(p.price)}</span>
          {off > 0 && <s className="mrp">{inr(p.mrp)}</s>}
        </div>
        {p.moq > 1 && <div className="moq">Min. order {p.moq} pcs</div>}
        <button className="btn btn-outline btn-sm pcard-add" onClick={() => addToCart(p, p.moq || 1)} disabled={!p.inStock}>
          {p.inStock ? <>Add to gift list</> : 'Out of stock'}
        </button>
      </div>
    </article>
  );
}
