import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import ProductCard from './ProductCard';
import Icon from './Icon';
import { api } from '../api';

// Horizontal product rail with optional tabs. tabs: [{ label, params, to }]
export default function ProductRail({ title, subtitle, tabs }) {
  const [active, setActive] = useState(0);
  const [items, setItems] = useState(null);
  const track = useRef(null);

  useEffect(() => {
    setItems(null);
    api.products({ limit: 12, ...tabs[active].params }).then((r) => setItems(r.items)).catch(() => setItems([]));
  }, [active]); // eslint-disable-line react-hooks/exhaustive-deps

  const scroll = (dir) => track.current?.scrollBy({ left: dir * track.current.clientWidth * 0.8, behavior: 'smooth' });

  return (
    <section className="section">
      <div className="container">
        <div className="section-head">
          <div>
            <h2>{title}</h2>
            {subtitle && <p className="muted">{subtitle}</p>}
          </div>
          <div className="rail-controls">
            <button className="icon-btn round" onClick={() => scroll(-1)} aria-label="Scroll left"><Icon name="chevron" className="flip" /></button>
            <button className="icon-btn round" onClick={() => scroll(1)} aria-label="Scroll right"><Icon name="chevron" /></button>
          </div>
        </div>
        {tabs.length > 1 && (
          <div className="tabs" role="tablist">
            {tabs.map((t, i) => (
              <button key={t.label} role="tab" aria-selected={i === active} className={i === active ? 'active' : ''} onClick={() => setActive(i)}>{t.label}</button>
            ))}
          </div>
        )}
        <div className="rail" ref={track}>
          {(items || Array.from({ length: 5 })).map((p, i) => (p ? <ProductCard key={p.id} product={p} /> : <div key={i} className="pcard skeleton" />))}
          {items?.length === 0 && <p className="muted">Nothing here yet.</p>}
        </div>
        <div className="center"><Link to={tabs[active].to} className="btn btn-outline">View all <Icon name="chevron" size={16} /></Link></div>
      </div>
    </section>
  );
}
