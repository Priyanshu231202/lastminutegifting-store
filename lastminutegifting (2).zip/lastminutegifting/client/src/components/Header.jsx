import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import Icon from './Icon';
import { useStore } from '../store';

const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

export default function Header() {
  const { settings, catalog, cartCount, city, setCity } = useStore();
  const [q, setQ] = useState('');
  const [drawer, setDrawer] = useState(false);
  const [openMenu, setOpenMenu] = useState(null);
  const navigate = useNavigate();
  const { pathname } = useLocation();
  useEffect(() => { setDrawer(false); setOpenMenu(null); }, [pathname]);

  // Only categories that actually have products appear in the menu
  const cats = (catalog.categories || []).filter((c) => c.count > 0);

  // Top nav structure. Each menu = columns of { title, links }
  const menus = [
    { label: 'Occasions', to: '/collections/all', cols: [
      { title: 'Shop by occasion', links: (catalog.occasions || []).filter((o) => !['for-him', 'for-her'].includes(o.slug)).map((o) => ({ label: o.name, to: `/collections/${o.slug}` })) },
      { title: 'Shop by recipient', links: [{ label: 'For Him', to: '/collections/for-him' }, { label: 'For Her', to: '/collections/for-her' }, { label: 'For Teams', to: '/collections/employee-welcome' }, { label: 'For Clients', to: '/collections/corporate' }] },
    ] },
    ...cats.map((c) => ({
      label: c.name, to: `/collections/${c.slug}`,
      cols: [{ title: c.name, to: `/collections/${c.slug}`, links: (c.subs || c.subcategories.map((n) => ({ name: n, slug: slug(n), count: 1 }))).filter((s) => s.count > 0).map((s) => ({ label: s.name, to: `/collections/${c.slug}?sub=${s.slug}` })) }],
    })),
    { label: 'Trophies & Awards', to: '/trophies' },
    { label: 'Same-Day Delivery', to: '/collections/same-day', hot: true },
  ];

  const submit = (e) => {
    e.preventDefault();
    if (q.trim()) navigate(`/search?q=${encodeURIComponent(q.trim())}`);
  };
  const cityName = settings?.cities?.find((c) => c.slug === city)?.name;

  return (
    <header className="site-header">
      {settings?.announcement && <div className="announce"><Icon name="bolt" size={14} /> {settings.announcement}</div>}
      <div className="header-main container">
        <button className="icon-btn only-mobile" onClick={() => setDrawer(true)} aria-label="Open menu"><Icon name="menu" /></button>
        <Link to="/" className="logo" aria-label="lastminutegifting home">
          <span className="logo-mark"><Icon name="gift" size={20} stroke={2} /></span>
          <span className="logo-text">lastminute<b>gifting</b></span>
        </Link>
        <form className="search" onSubmit={submit} role="search">
          <Icon name="search" size={18} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search bags, diaries, bottles, keychains…" aria-label="Search gifts" />
        </form>
        <div className="header-actions">
          <button className="city-pill" onClick={() => setCity(null)} title="Change delivery city">
            <Icon name="pin" size={16} />
            <span><small>Deliver to</small>{cityName || 'Select city'}</span>
          </button>
          <Link to="/bulk-enquiry" className="btn btn-dark btn-sm only-desktop"><Icon name="building" size={16} /> Bulk / Corporate</Link>
          <Link to="/cart" className="icon-btn cart-btn" aria-label={`Gift list, ${cartCount} items`}>
            <Icon name="bag" size={22} />
            {cartCount > 0 && <span className="count">{cartCount > 99 ? '99+' : cartCount}</span>}
          </Link>
        </div>
      </div>

      <nav className="mainnav only-desktop" onMouseLeave={() => setOpenMenu(null)}>
        <ul className="container">
          {menus.map((m, i) => (
            <li key={m.label} onMouseEnter={() => setOpenMenu(m.cols?.length ? i : null)}>
              <NavLink to={m.to} className={m.hot ? 'hot' : ''}>
                {m.hot && <Icon name="bolt" size={14} />}{m.label}{m.cols?.length ? <Icon name="down" size={14} /> : null}
              </NavLink>
              {openMenu === i && m.cols?.length > 0 && (
                <div className="mega">
                  <div className="container mega-inner">
                    {m.cols.map((col) => (
                      <div key={col.title} className="mega-col">
                        {col.to ? <Link to={col.to} className="mega-title">{col.title}</Link> : <span className="mega-title">{col.title}</span>}
                        {col.links.map((l) => <Link key={l.to + l.label} to={l.to}>{l.label}</Link>)}
                        {col.to && <Link to={col.to} className="view-all">View all <Icon name="chevron" size={14} /></Link>}
                      </div>
                    ))}
                    <Link to="/bulk-enquiry" className="mega-promo">
                      <Icon name="building" size={26} />
                      <strong>Ordering 50+ pieces?</strong>
                      <span>Get logo branding and bulk pricing in one quote.</span>
                      <em>Get a quote →</em>
                    </Link>
                  </div>
                </div>
              )}
            </li>
          ))}
        </ul>
      </nav>

      {/* Mobile drawer */}
      <div className={`drawer-backdrop ${drawer ? 'open' : ''}`} onClick={() => setDrawer(false)} />
      <aside className={`drawer ${drawer ? 'open' : ''}`} aria-hidden={!drawer}>
        <div className="drawer-head">
          <span className="logo-text">lastminute<b>gifting</b></span>
          <button className="icon-btn" onClick={() => setDrawer(false)} aria-label="Close menu"><Icon name="close" /></button>
        </div>
        <Link to="/collections/same-day" className="drawer-hot"><Icon name="bolt" size={16} /> Same-Day Delivery</Link>
        <Link to="/trophies" className="drawer-link">Trophies & Awards</Link>
        {menus.filter((m) => m.cols?.length).map((m) => (
          <details key={m.label}>
            <summary>{m.label}<Icon name="down" size={16} /></summary>
            {m.cols.flatMap((c) => [
              c.to ? <Link key={c.title} to={c.to} className="d-title">{c.title}</Link> : <span key={c.title} className="d-title">{c.title}</span>,
              ...c.links.map((l) => <Link key={l.to + l.label} to={l.to}>{l.label}</Link>),
            ])}
          </details>
        ))}
        <Link to="/bulk-enquiry" className="btn btn-primary drawer-cta"><Icon name="building" size={16} /> Bulk / Corporate Enquiry</Link>
      </aside>
    </header>
  );
}
