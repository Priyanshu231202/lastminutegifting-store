import { imgUrl } from '../api';

// Shows the product photo, or a tasteful placeholder until you upload your own.
const tints = {
  pens: ['#2b2640', '#f2b84b'], notebooks: ['#5b3a2e', '#f3d9b1'], drinkware: ['#1f4e5f', '#9ed8db'],
  bags: ['#3d3a36', '#e0c9a6'], 'home-decor': ['#6b2f3a', '#f5c6aa'], 'eco-friendly': ['#35533a', '#c9e4b4'],
  electronics: ['#20243a', '#8fb3ff'], jewellery: ['#4a2d4f', '#f1c6e7'], novelties: ['#7a3b1d', '#ffd08a'],
  'gift-sets': ['#1d1a26', '#e4572e'],
};

const glyphs = {
  pens: <path d="M20 80 70 30l10 10-50 50-14 4 4-14zM64 36l10 10" />,
  notebooks: <><rect x="28" y="18" width="46" height="64" rx="4" /><path d="M38 18v64M46 34h20M46 44h20" /></>,
  drinkware: <><path d="M38 26h24v8l4 6v40a4 4 0 0 1-4 4H38a4 4 0 0 1-4-4V40l4-6z" /><path d="M38 20h24v6H38z" /></>,
  bags: <><rect x="24" y="36" width="52" height="44" rx="6" /><path d="M38 36v-6a12 12 0 0 1 24 0v6M24 52h52" /></>,
  'home-decor': <><circle cx="50" cy="50" r="30" /><path d="M50 32v18l12 8" /></>,
  'eco-friendly': <path d="M28 72c0-30 20-44 46-46-2 26-16 46-46 46zm0 0 22-22" />,
  electronics: <><rect x="32" y="20" width="36" height="60" rx="6" /><path d="M44 30h12M46 70h8" /></>,
  jewellery: <path d="M50 78 24 44l10-14h32l10 14-26 34zM24 44h52M40 30l10 48M60 30 50 78" />,
  novelties: <><circle cx="50" cy="60" r="14" /><path d="M50 46V24M42 24h16" /></>,
  'gift-sets': <><rect x="24" y="44" width="52" height="36" rx="3" /><path d="M20 36h60v10H20zM50 36v44M50 36s-6-14-14-10 4 10 14 10zm0 0s6-14 14-10-4 10-14 10z" /></>,
};

export default function ProductImage({ product, index = 0, className = '' }) {
  const src = product?.images?.[index] ?? (index === 0 ? product?.image : null);
  if (src) return <img className={`pimg ${className}`} src={imgUrl(src)} alt={product.name} loading="lazy" />;
  const [bg, fg] = tints[product?.category] || tints['gift-sets'];
  return (
    <div className={`pimg placeholder ${className}`} style={{ '--ph-bg': bg, '--ph-fg': fg }} role="img" aria-label={product?.name}>
      <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
        {glyphs[product?.category] || glyphs['gift-sets']}
      </svg>
      <span>Photo coming soon</span>
    </div>
  );
}
