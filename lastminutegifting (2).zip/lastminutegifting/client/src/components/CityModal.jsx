import { useState } from 'react';
import { useStore } from '../store';
import Icon from './Icon';

// Location gate: only active cities (Delhi for now) can browse; others join a waitlist message.
export default function CityModal() {
  const { settings, city, setCity } = useStore();
  const [blocked, setBlocked] = useState(null);
  if (!settings?.cities || city) return null;

  return (
    <div className="modal-backdrop">
      <div className="modal city-modal" role="dialog" aria-modal="true" aria-labelledby="city-title">
        <span className="modal-icon"><Icon name="pin" size={26} /></span>
        <h2 id="city-title">Where should we deliver?</h2>
        <p className="muted">We deliver in 2–4 hours, so we need your city first.</p>
        <div className="city-grid">
          {settings.cities.map((c) => (
            <button key={c.slug} className={`city-opt ${!c.active ? 'soon' : ''}`}
              onClick={() => (c.active ? setCity(c.slug) : setBlocked(c.name))}>
              <strong>{c.name}</strong>
              <small>{c.active ? '2–4 hr delivery' : 'Coming soon'}</small>
            </button>
          ))}
        </div>
        {blocked && (
          <p className="notice">
            We're launching in {blocked} soon! For bulk or corporate orders to {blocked}, you can still{' '}
            <a href="/bulk-enquiry" onClick={() => setCity('delhi')}>send us an enquiry</a>.
          </p>
        )}
      </div>
    </div>
  );
}
