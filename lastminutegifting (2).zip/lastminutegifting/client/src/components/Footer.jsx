import { Link } from 'react-router-dom';
import { useStore } from '../store';
import Icon from './Icon';

export default function Footer() {
  const { settings, catalog } = useStore();
  const s = settings || {};
  return (
    <footer className="site-footer">
      <div className="container footer-perks">
        {[
          ['bolt', '2–4 hour delivery', 'Across Delhi, 7 days a week'],
          ['gift', 'Gift-wrapped free', 'With a handwritten note'],
          ['pen', 'Personalisation', 'Engraving & logo printing'],
          ['building', 'Bulk pricing', 'Special rates from 50+ units'],
        ].map(([i, t, d]) => (
          <div key={t} className="perk"><Icon name={i} size={24} /><div><strong>{t}</strong><span>{d}</span></div></div>
        ))}
      </div>
      <div className="container footer-grid">
        <div className="footer-brand">
          <span className="logo-text light">lastminute<b>gifting</b></span>
          <p>{s.tagline || 'Gifts delivered in 2–4 hours across Delhi.'} Bags, notebooks, gift sets, bottles, mugs, keychains, trophies and awards — for people and for companies.</p>
          <div className="footer-contact">
            {s.phone && <a href={`tel:${s.phone.replace(/\s/g, '')}`}><Icon name="phone" size={16} /> {s.phone}</a>}
            {s.email && <a href={`mailto:${s.email}`}><Icon name="mail" size={16} /> {s.email}</a>}
            {s.address && <span><Icon name="pin" size={16} /> {s.address}</span>}
          </div>
        </div>
        <div>
          <h4>Shop</h4>
          {(catalog.categories || []).slice(0, 7).map((c) => <Link key={c.slug} to={`/collections/${c.slug}`}>{c.name}</Link>)}
        </div>
        <div>
          <h4>Occasions</h4>
          {(catalog.occasions || []).slice(0, 7).map((o) => <Link key={o.slug} to={`/collections/${o.slug}`}>{o.name}</Link>)}
        </div>
        <div>
          <h4>Help</h4>
          <Link to="/bulk-enquiry">Bulk & Corporate</Link>
          <Link to="/pages/about">About us</Link>
          <Link to="/pages/faq">FAQs</Link>
          <Link to="/pages/shipping">Delivery policy</Link>
          <Link to="/pages/refunds">Returns & refunds</Link>
          <Link to="/pages/terms">Terms & privacy</Link>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} lastminutegifting. All rights reserved.</span>
        <span>Made in Delhi with ♥</span>
      </div>
    </footer>
  );
}
