# lastminutegifting — React + Node.js store

Gifting storefront for Delhi with 2–4 hour delivery. Customers build a **gift list** (cart) and send an **enquiry** — no online payment. You confirm on call/WhatsApp and share a payment link. There's also a separate **Bulk / Corporate quote** form.

```
client/   React (Vite) storefront + admin panel
server/   Node.js (Express) API, JSON data files, photo uploads
```

## Run it locally

Needs Node.js 18+.

```bash
npm run install:all         # installs server + client
cp server/.env.example server/.env   # then set ADMIN_TOKEN to your own password
npm run seed                # loads the sample catalogue (only needed once)

# two terminals:
npm run dev:server          # API on http://localhost:5000
npm run dev:client          # site on http://localhost:5173
```

Admin panel: **http://localhost:5173/admin** — log in with the `ADMIN_TOKEN` from `server/.env`.

## Your catalogue (already loaded)

`npm run seed` loads **250 products** from your catalogues, with photos in `server/uploads/catalogue/`:

| Category | Items | Codes | Prices |
|---|---|---|---|
| Drinkware | 16 bottles, 15 mugs/tumblers | BOT-001…, MUG-001… | estimates |
| Keychains | 34 | K-01…K-35 (no K-29) | catalogue price incl. branding + GST, rounded up |
| Bags | 27 backpacks, 40 laptop/messenger, 21 sling | BG-101…, BG-201…, BG-301… | estimates; names are descriptive (catalogue had photos only) |
| Notebooks & Diaries | 54 | N-01…N-220 (duplicate codes renamed N-22A/B, N-31A/B) | estimates |
| Gift Sets | 35 diary & pen sets, 8 card holders | DG-01…DG-35, W-01…W-08 | estimates |
| Trophies & Awards | quote page at `/trophies` | none | on request |

`server/data/my-catalogue.csv` has every product. Change prices in Excel, then run `npm run import -- data/my-catalogue.csv` to update the site (matched by SKU).
Note: re-running `npm run seed` resets products to the catalogue defaults.

## Add more products, photos and prices

**A. Admin panel (easiest for photos)**
Admin → Products → Edit. Upload photos (first photo = cover, second shows on hover), change price/MRP, description, personalisation options, occasions, and flags (bestseller, same-day, etc.). You can also edit the price straight in the product table.

**B. Spreadsheet import (fastest for the whole catalogue)**
1. Open `server/data/catalogue-template.csv` in Excel/Google Sheets and fill one row per product.
   Multi-value columns (`features`, `branding`, `occasions`, `images`) use `|` between values.
   `category` must be one of: `pens, notebooks, drinkware, bags, home-decor, eco-friendly, electronics, jewellery, novelties, gift-sets`.
2. Put photos in `server/uploads/` and reference them as `/uploads/filename.jpg`.
3. Import:
   ```bash
   cd server
   npm run import -- data/my-catalogue.csv --replace   # --replace removes the samples
   ```
   Re-running without `--replace` updates rows by SKU and adds new ones — handy for price changes.

Categories, sub-categories and occasions live in `server/data/categories.json`.

## Store settings

Admin → Store settings: phone, **WhatsApp number** (enables the floating chat button and "Chat on WhatsApp" links), email, announcement bar text, and which cities are open. Noida, Gurugram and Chandigarh are set up as "coming soon" — tick them when you launch there.

## Enquiry emails (optional)

Fill `SMTP_*` in `server/.env` to get an email for every new enquiry. For Gmail use `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=465`, your address as `SMTP_USER`, and a Google **App Password** as `SMTP_PASS`. Enquiries always appear in Admin → Enquiries regardless.

## Deploy (one server)

```bash
npm run build     # builds the React app into client/dist
npm start         # Express serves the API and the built site on PORT
```

Works on any VPS (Hostinger, DigitalOcean, AWS Lightsail) with PM2, or Render/Railway. Because data and photos are files, use a host with a **persistent disk** and back up `server/data/` and `server/uploads/`.
To host the frontend separately (e.g. Vercel), set `VITE_API_URL=https://your-api-domain` before building.

## Pages

Home · `/collections/:category|:occasion|all|bestsellers|new|same-day` (filters: type, price, same-day; sort) · `/search?q=` · `/products/:slug` · `/cart` · `/checkout` · `/bulk-enquiry` · `/pages/about|faq|shipping|refunds|terms` · `/admin`

Policy text lives in `client/src/pages/InfoPage.jsx`; home hero/FAQ copy in `client/src/pages/Home.jsx`.
