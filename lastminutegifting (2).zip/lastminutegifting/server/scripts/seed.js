// Seeds the store with YOUR catalogue: bottles, mugs & tumblers, and keychains.
// Keychain prices come from the catalogue (incl. branding + 18% GST, rounded up).
// Drinkware prices are ESTIMATES — edit them in Admin → Products (or via CSV import).
// Photos live in server/uploads/catalogue/.
const fs = require('fs');
const path = require('path');
const { write } = require('../src/store');

const categories = [
  { slug: 'drinkware', name: 'Drinkware', blurb: 'Insulated bottles, coffee tumblers and travel mugs — engraved with a name or your logo.',
    subcategories: ['Bottles', 'Tumblers', 'Mugs'] },
  { slug: 'keychains', name: 'Keychains', blurb: 'Metal, leather, cork and carabiner keychains with your logo engraved.',
    subcategories: ['Metal Keychains', 'Leather & Cork', 'Carabiner Hooks'] },
  { slug: 'bags', name: 'Bags', blurb: 'Laptop backpacks, office messenger bags and sling bags — with logo branding for teams.',
    subcategories: ['Backpacks', 'Laptop & Messenger Bags', 'Sling Bags'] },
  { slug: 'notebooks', name: 'Notebooks & Diaries', blurb: 'Hardcover, executive flap and premium notebooks — ready for logo debossing or a metal name plate.',
    subcategories: ['Classic Notebooks', 'Executive Notebooks', 'Premium Collection'] },
  { slug: 'gift-sets', name: 'Gift Sets', blurb: 'Boxed diary-and-pen sets and card holders — ready to gift, easy to brand.',
    subcategories: ['Diary & Pen Gift Sets', 'Card Holders'] },
];

const occasions = [
  { slug: 'corporate', name: 'Corporate & Clients' },
  { slug: 'employee-welcome', name: 'Employee Welcome' },
  { slug: 'diwali', name: 'Diwali & Festive' },
  { slug: 'birthday', name: 'Birthday' },
  { slug: 'housewarming', name: 'Housewarming' },
  { slug: 'farewell', name: 'Farewell' },
  { slug: 'eco', name: 'Eco-Friendly' },
  { slug: 'for-him', name: 'For Him' },
  { slug: 'for-her', name: 'For Her' },
];

const slugify = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
const products = [];
let id = 1001;
const add = (p) => products.push({
  id: String(id++),
  slug: slugify(`${p.name} ${p.sku}`),
  mrp: p.price,
  bulkNote: 'Special pricing from 50+ units',
  inStock: true,
  featured: false, bestseller: false, newArrival: false,
  createdAt: new Date(Date.now() - (id - 1000) * 3600e3).toISOString(),
  ...p,
});

/* ---------- Bottles (Bottles Catalogue) ---------- */
// [code, name, capacity, description, material, estPrice, occasions, flags]
const bottles = [
  ['001', 'Ecoweave', '500 ml', 'Elegant bottle with a natural jute sleeve, bamboo lid and premium craftsmanship — a stylish design for everyday use.', 'Borosilicate glass with jute sleeve', 449, ['eco', 'corporate', 'for-her'], 'b'],
  ['002', 'Bamboo Line', '500 ml', 'Premium bamboo-finish flask combining natural warmth with a sleek modern shape — for offices, travel, gifting and daily hydration.', 'Stainless steel flask with tea strainer, double-wall vacuum insulated', 599, ['eco', 'corporate', 'diwali'], 'bf'],
  ['003', 'Metro Strap', '500 ml', 'Practical carry-strap bottle designed for comfortable portability and secure handling during travel, work or outdoors.', 'BPA-free, double-wall, food-grade 304 stainless steel', 499, ['corporate', 'for-him'], ''],
  ['004', 'Classic Curve', '500 ml', 'Durable metal water bottle with a sleek modern profile — versatile for offices, travel, fitness and gifting.', 'BPA-free, double-wall, food-grade 304 stainless steel', 449, ['corporate', 'employee-welcome', 'birthday'], 'b'],
  ['005', 'Classic Curve XL', '1000 ml', 'The Classic Curve in a large 1-litre size — durable, sleek and made for all-day hydration.', 'BPA-free, double-wall, food-grade 304 stainless steel', 699, ['corporate', 'for-him'], ''],
  ['006', 'Aura', '500 ml', 'Premium matte-finish bottle with a sleek modern shape, available in soft colours — for offices, travel and daily hydration.', 'Matte-finish 304 stainless steel, leakproof, BPA-free', 549, ['for-her', 'birthday', 'corporate'], 'bn'],
  ['007', 'Aura Non-Coated', '500 ml', 'Matte-finish steel bottle with thermal insulation and a clean modern silhouette.', 'Double-wall stainless steel', 499, ['corporate', 'employee-welcome'], ''],
  ['008', 'Silver Crown', '750 / 1000 ml', 'Minimalist flat-top bottle with a clean cylindrical form, coordinated colours and modern lid detailing for everyday professional use.', 'Stainless steel, BPA-free, food grade', 649, ['corporate', 'for-him'], ''],
  ['009', 'Loop-Handle', '500 ml', 'Loop-handle bottle with a wooden lid — easy carrying, confident grip and compact styling for commuting, travel or work.', 'Stainless steel with wooden lid, leakproof, reusable', 549, ['eco', 'corporate'], 'n'],
  ['011', 'Cork-Base', '500 ml', 'Matte-black insulated bottle with an integrated carry lid, elegant curved profile and a natural cork base.', 'Matte-finish metal with loop cap and cork base, leak-resistant', 599, ['eco', 'for-him', 'corporate'], 'f'],
  ['012', 'Trail Strap', '500 ml', 'Compact curved insulated bottle with a secure screw lid and durable wrist strap, in black or white.', 'Matte-finish stainless steel, leakproof carry strap', 549, ['for-him', 'birthday'], ''],
  ['013', 'Urban Flat-Top Smart Bottle', '500 ml', 'Smart insulated bottle with a digital temperature display on the lid, slim body and stylish colours.', 'Double-wall stainless steel, digital touch-lid temperature screen', 599, ['birthday', 'corporate', 'for-him', 'for-her'], 'bf'],
  ['014', 'Orbit Loop', '250 ml', 'Compact stainless-steel bottle with a loop handle, smooth rounded body and vibrant colours — perfect for kids and short trips.', 'Stainless steel, double-wall, leakproof, vacuum insulated', 399, ['birthday', 'for-her'], 'n'],
  ['015', 'Arc Handle', '500 ml', 'Sleek matte-black bottle with a sturdy integrated carry handle, secure lid and minimalist profile.', 'Stainless steel — break, condensation, leak and rust resistant', 599, ['for-him', 'corporate'], ''],
  ['016', 'Mug Grip', '500 ml', 'Insulated bottle with a transparent cup-style lid, side handle and slim body in black or white.', 'Double-walled stainless steel, rustproof and leakproof', 649, ['corporate', 'farewell'], ''],
  ['017', 'Duo Cup Flask Set', '500 ml', 'Flask with two cups for sharing tea or coffee — ideal for travel, office breaks and thoughtful gifting.', 'Stainless steel thermos for tea & coffee, leakproof', 899, ['diwali', 'housewarming', 'corporate'], 'bf'],
];
bottles.forEach(([code, name, cap, desc, mat, price, occ, f], i) => add({
  sku: `BOT-${code}`, name: `${name} Bottle`.replace('Set Bottle', 'Set').replace('Smart Bottle Bottle', 'Smart Bottle'),
  category: 'drinkware', subcategory: 'Bottles', price, mrp: Math.round(price * 1.3 / 10) * 10 - 1, moq: 1,
  description: desc, capacity: cap,
  features: [`Capacity: ${cap}`, 'Double-wall vacuum insulation — hot or cold for hours', 'Leak-proof lid', mat],
  branding: ['Laser engraving (name)', 'Laser engraving (company logo)', 'UV logo print'],
  bulkNote: 'Logo branding from 50 pcs', occasions: occ, images: [`/uploads/catalogue/bot-${String(i + 1).padStart(3, '0')}.jpg`],
  sameDay: true, featured: f.includes('f'), bestseller: f.includes('b'), newArrival: f.includes('n'),
}));

/* ---------- Mugs, Sippers & Tumblers ---------- */
const mugs = [
  ['001', 'Urban Carry Tumbler', 'Tumblers', '900 / 1200 ml', 'Large insulated tumbler with an ergonomic carry handle, leak-resistant lid and excellent temperature retention.', 'Premium stainless steel', 999, ['for-him', 'birthday', 'corporate'], 'bn'],
  ['002', 'Sip Master Tumbler', 'Tumblers', '500 ml', 'Double-wall tumbler with a sturdy handle, reusable straw and spill-resistant lid.', 'Premium stainless steel', 899, ['for-her', 'birthday'], 'bf'],
  ['003', 'Coffee Vault Tumbler', 'Tumblers', '500 ml', 'Vacuum-insulated coffee tumbler with a leak-resistant lid and sleek stainless body.', 'Premium stainless steel', 599, ['corporate', 'employee-welcome', 'for-her'], 'b'],
  ['004', 'Grip Brew Tumbler', 'Tumblers', '380 / 510 ml', 'Insulated coffee tumbler with a textured grip and leak-resistant lid.', 'Superior stainless steel', 549, ['corporate', 'employee-welcome'], ''],
  ['005', 'Stealth Sip Travel Mug', 'Tumblers', '300 / 400 ml', 'Premium insulated travel mug with a secure locking lid and sleek finish.', 'Thermosteel vacuum-insulated', 499, ['for-him', 'corporate'], ''],
  ['006', 'Cozy Sip Coffee Mug', 'Mugs', '300 / 500 ml', 'Insulated coffee mug with a comfortable handle and spill-resistant lid.', 'Black stainless steel, insulated, with handle', 549, ['corporate', 'for-him'], 'n'],
  ['007', 'Chill Cup', 'Tumblers', '250 / 360 ml', 'Double-wall insulated cup with a spill-resistant lid and elegant rounded design.', 'Stainless steel travel coffee cup', 449, ['for-her', 'birthday'], ''],
  ['008', 'Cork Brew Mug', 'Mugs', '300 / 450 ml', 'Ceramic coffee mug with a natural cork base, comfortable handle and spill-proof lid.', 'Ceramic with cork base and spill-proof lid', 499, ['eco', 'corporate', 'housewarming'], 'f'],
  ['009', 'Urban Brew Mug', 'Mugs', '450 ml', 'Modern insulated mug with an ergonomic handle and spill-resistant lid.', 'Stainless-steel interior, comfortable handle', 549, ['corporate', 'employee-welcome'], ''],
  ['010', 'Swift Grip Anti-Tip Mug', 'Mugs', '470 ml', 'Insulated travel mug with an ergonomic side handle and suction base that resists tipping over.', 'Stainless steel, comfortable handle', 599, ['corporate', 'for-him'], 'n'],
  ['011', 'Bamboo Brew Mug', 'Mugs', '350 ml', 'Bamboo-style insulated mug with a comfortable handle and lid — warm, natural look.', 'Bamboo-finish mug with lid and handle', 449, ['eco', 'corporate', 'diwali'], 'b'],
  ['012', 'Eco Sip Cup', 'Tumblers', '510 ml', 'Lightweight reusable cup with a cork grip and secure bamboo lid, for hot or cold drinks.', 'Eco cork mug with bamboo lid', 349, ['eco', 'employee-welcome'], ''],
  ['013', 'Flex Self-Stirring Mug', 'Mugs', '350 ml', 'Rechargeable self-stirring mug — magnetic stirring at the press of a button.', 'Rechargeable automatic magnetic self-stirring mechanism', 799, ['birthday', 'for-him', 'for-her'], 'fn'],
  ['014', 'Cork Chill Tumbler', 'Tumblers', '450 ml', 'Insulated stainless tumbler with a natural cork base and clear lid — made for the boardroom.', 'Stainless steel boardroom tumbler with lid', 649, ['corporate', 'eco'], 'f'],
  ['015', 'Metro Sip Tumbler', 'Tumblers', '350 ml', 'Travel tumbler with a secure flip lid and premium matte finish.', 'Stainless steel with matte-finish texture', 549, ['corporate', 'for-him', 'farewell'], ''],
];
mugs.forEach(([code, name, sub, cap, desc, mat, price, occ, f], i) => add({
  sku: `MUG-${code}`, name, category: 'drinkware', subcategory: sub, price, mrp: Math.round(price * 1.3 / 10) * 10 - 1, moq: 1,
  description: desc, capacity: cap,
  features: [`Capacity: ${cap}`, 'Double-wall insulation', 'Leak-proof / spill-resistant lid', 'BPA-free, food grade', mat],
  branding: ['Laser engraving (name)', 'Laser engraving (company logo)', 'UV logo print'],
  bulkNote: 'Logo branding from 50 pcs', occasions: occ, images: [`/uploads/catalogue/mug-${String(i + 1).padStart(3, '0')}.jpg`],
  sameDay: true, featured: f.includes('f'), bestseller: f.includes('b'), newArrival: f.includes('n'),
}));

/* ---------- Keychains (catalogue customer price incl. branding + 18% GST) ---------- */
// [code, name, priceInclGST, moq, description]
const keys = [
  ['01', 'Homio', 24.78, 100, 'House-shaped metal keychain with a glossy black insert and polished finish. Ideal for real estate promotions, corporate gifting and custom branding.'],
  ['02', 'Royal Oval', 24.78, 100, 'Elegant oval metal keychain with a glossy black insert and polished finish.'],
  ['03', 'Executive', 24.78, 100, 'Minimalist rectangular metal keychain with a sleek dark insert and polished finish.'],
  ['04', 'Prestige', 24.78, 100, 'Distinctive abstract metal keychain with a glossy black insert and polished frame.'],
  ['05', 'Summit', 24.78, 50, 'Premium rectangular metal keychain with a glossy black insert and polished frame.'],
  ['06', 'Orbit', 24.78, 100, 'Elegant round metal keychain with a glossy black insert and polished silver finish.'],
  ['07', 'Urban Edge', 29.50, 100, 'Contemporary metal keychain with a sleek black insert and polished frame — great for employee rewards.'],
  ['08', 'Golden Crest', 29.50, 100, 'Premium gold-finish metal keychain with a sleek rectangular design and polished surface.'],
  ['09', 'Silver Edge', 29.50, 50, 'Sleek rectangular metal keychain with a glossy black insert and polished silver finish.'],
  ['10', 'Bamboo Prime', 29.50, 100, 'Eco-friendly keychain with a natural bamboo insert and polished metal frame.'],
  ['11', 'Vibrant Tag', 29.50, 100, 'Rectangular metal keychain with vibrant coloured inserts and a polished silver finish.'],
  ['12', 'Elite Circle', 41.30, 50, 'Premium round metal keychain with a glossy black insert and polished silver finish.'],
  ['13', 'Titan Edge', 41.30, 50, 'Premium rectangular metal keychain with a glossy black insert and distinctive metal accent.'],
  ['14', 'Rose Orbit', 44.84, 50, 'Elegant round rose-gold keychain with a glossy black insert and polished finish.'],
  ['15', 'Golden Orbit', 44.84, 50, 'Elegant round keychain with a glossy black insert and premium gold finish.'],
  ['16', 'Fusion Curve', 44.84, 50, 'Metal keychain with vibrant coloured inserts and a polished silver finish.'],
  ['17', 'Golden Fusion', 46.02, 50, 'Gold-finish metal keychain with a sleek coloured insert and elegant design.'],
  ['18', 'Silver Orbit', 46.02, 50, 'Round metal keychain with a glossy black insert and polished silver finish.'],
  ['19', 'Leather Crest', 48.38, 50, 'Leather loop keychain with a polished metal accent and contemporary design.'],
  ['20', 'Executive Loop', 48.38, 50, 'Leather loop keychain with a polished metal plate and contemporary design.'],
  ['21', 'Eco Loop', 49.56, 50, 'Eco-friendly keychain with a natural cork loop and premium metal accent.'],
  ['22', 'Royal Loop', 53.10, 50, 'Leather loop keychain with a polished metal plate — refined executive gifting.'],
  ['23', 'Smart Hook', 53.10, 50, 'Carabiner keychain with a durable metal hook and colourful strap options.'],
  ['24', 'Home Loop', 53.10, 50, 'House-shaped keychain with a sleek metal finish, leather strap and secure clasp. Ideal for real estate promotions.'],
  ['25', 'Black Elite', 53.10, 50, 'Black metal keychain with a sleek leather loop and matte finish.'],
  ['26', 'Metro Flip', 54.28, 50, 'Modern rectangular metal keychain with a sleek black panel and polished chrome frame.'],
  ['27', 'Dual Link', 54.28, 50, 'Dual-ring metal keychain with a sleek leather strap and polished finish.'],
  ['28', 'Classic Clip', 54.28, 50, 'Leather and metal keychain with a sleek rectangular frame and stylish strap options.'],
  ['30', 'Eco Hook', 54.28, 50, 'Eco-friendly carabiner keychain with a natural cork strap and polished metal finish.'],
  ['31', 'Rose Hook', 56.64, 50, 'Carabiner-style keychain with a durable rose-gold hook and sleek strap.'],
  ['32', 'Eco Shadow', 56.64, 50, 'Eco-friendly carabiner keychain with a natural cork accent and black metal finish.'],
  ['33', 'Golden Hook', 56.64, 50, 'Gold-finish carabiner keychain with a sleek leather strap and polished accents.'],
  ['34', 'Golden Home', 57.82, 50, 'House-shaped keychain with a polished gold finish and leather strap. Ideal for real estate promotions.'],
  ['35', 'Heritage Coin', 62.54, 60, 'Round metal keychain with an intricate engraved design — for commemorative giveaways.'],
];
const leather = ['19', '20', '21', '22', '24', '25', '27', '28', '34'];
const hooks = ['23', '30', '31', '32', '33'];
keys.forEach(([code, name, gst, moq, desc]) => {
  const sub = hooks.includes(code) ? 'Carabiner Hooks' : leather.includes(code) ? 'Leather & Cork' : 'Metal Keychains';
  const occ = ['corporate', 'employee-welcome'];
  if (/house/i.test(desc)) occ.push('housewarming');
  if (/eco|cork|bamboo/i.test(desc)) occ.push('eco');
  if (/leather/i.test(desc)) occ.push('for-him');
  add({
    sku: `K-${code}`, name: `${name} Keychain`, category: 'keychains', subcategory: sub,
    price: Math.ceil(gst), mrp: Math.ceil(gst), moq,
    description: `${desc} Price includes your logo branding and 18% GST.`,
    features: ['Logo branding included in price', `Minimum order ${moq} pcs`, 'Price incl. 18% GST', 'Gift-ready finish'],
    branding: ['Laser engraving (company logo)', 'Laser engraving (name/text)'],
    bulkNote: `Price includes logo branding · MOQ ${moq}`,
    occasions: occ, images: [`/uploads/catalogue/key-${code}.jpg`],
    sameDay: false,
    bestseller: ['01', '07', '10', '20', '23'].includes(code),
    newArrival: ['30', '32', '33', '35'].includes(code),
    featured: ['15', '21', '24'].includes(code),
  });
});


/* ============ Round 2: bags, notebooks, gift sets, card holders (prices are ESTIMATES) ============ */
const est = (price) => Math.round(price * 1.3 / 10) * 10 - 1; // display MRP ~30% above price

// ---------- Bags (photos only in catalogue; names are descriptive) ----------
// [code, name, price, occasions]
const backpacks = [
  [101, 'Roll-Top Commuter Backpack', 1299], [102, 'Classic Black Office Backpack', 1199], [103, 'Navy Textured Mini Backpack', 999],
  [104, 'Compact Roll-Top Backpack', 1099], [105, 'Cabin Travel Backpack', 1799], [106, 'Sage Two-Tone Laptop Backpack', 1299],
  [107, 'Brown Executive Leatherette Backpack', 1499], [108, 'Black PU Leather Backpack', 1199], [109, 'Black Everyday Laptop Backpack', 1099],
  [110, 'Teal Two-Tone Laptop Backpack', 1099], [111, 'Kids Aqua Print Backpack', 799, ['birthday']], [112, 'Kids Galaxy Print Backpack', 799, ['birthday']],
  [113, 'Black Slim Laptop Backpack', 1299], [114, 'Black & Grey Pro Laptop Backpack', 1299], [115, 'Grey & Navy Sport Backpack', 999],
  [116, 'Navy Multi-Compartment Backpack', 1199], [117, 'Black Office Laptop Backpack', 999], [118, 'Vintage Brown Leatherette Backpack', 1599],
  [119, 'Charcoal Business Backpack', 1199], [120, 'Anti-Theft Laptop Backpack with USB', 1499], [121, 'Grey Trekker Laptop Backpack', 1299],
  [122, 'Convertible Tote Backpack', 1399], [123, 'Grey Stripe Laptop Backpack', 1299], [124, 'Black Orange-Zip Backpack', 1099],
  [125, 'Black Essential Laptop Backpack', 1099], [126, 'Navy Sport Laptop Backpack', 1199], [127, 'Black & Orange Sport Backpack', 1199],
];
const messengers = [
  [201, 'Chevron Print Laptop Sleeve', 699, ['for-her']], [202, 'Burgundy Leatherette Laptop Bag', 1799], [203, 'Croc-Texture Brown Laptop Bag', 1499],
  [204, 'Black Canvas Messenger Bag', 1399], [205, 'Black Executive Laptop Bag', 1599], [206, 'Dark Brown Executive Laptop Bag', 1599],
  [207, 'Navy Croc-Texture Laptop Bag', 1699], [208, 'Grey Slim Laptop Sleeve', 799], [209, 'Black Multi-Pocket Laptop Bag', 1599],
  [210, 'Brown Double-Zip Laptop Bag', 1699], [211, 'Brown Slim Briefcase', 1299], [212, 'Brown Slim Laptop Messenger', 1499],
  [213, 'Grey & Black Laptop Tote', 1199, ['for-her']], [214, 'Tan Leatherette Laptop Bag', 1699], [215, 'Ikat Print Laptop Bag', 1199, ['for-her']],
  [216, 'Black & Tan Canvas Laptop Bag', 1299], [217, 'Brown Classic Laptop Bag', 1599], [218, 'Tan Buckle Laptop Bag', 1899],
  [219, 'Black Minimal Briefcase', 1399], [220, 'Brown Panelled Laptop Bag', 1499], [221, 'Black Slim Laptop Messenger', 1599],
  [222, 'Tan Flap Messenger Bag', 1899], [223, 'Grey Expandable Laptop Bag', 1299], [224, 'Brown Stitched Laptop Messenger', 1599],
  [225, 'Brown Sport-Trim Laptop Bag', 1599], [226, 'Black Multi-Pocket Office Bag', 1699], [227, 'Tan Vintage Laptop Bag', 1799],
  [228, 'Grey Felt & Tan Laptop Bag', 1399], [229, 'Grey & Brown Laptop Bag', 1299], [230, 'Burgundy Large Office Bag', 1899],
  [231, 'Black Expandable Laptop Bag', 1499], [232, 'Black Textured Laptop Bag', 1599], [233, 'Tan Slim Laptop Bag', 1399],
  [234, 'Black Double-Handle Office Bag', 1899], [235, 'Burgundy Multi-Zip Office Bag', 1899], [236, 'Black Flap Messenger Bag', 1699],
  [237, 'Black Nylon Laptop Messenger', 1299], [238, 'Black Compact Laptop Bag', 1099], [239, 'Cream & Brown Laptop Tote', 1199, ['for-her']],
  [240, 'Teal Printed Laptop Bag', 999, ['for-her']],
];
const slings = [
  [301, 'Grey Compact Crossbody Bag', 899], [302, 'Brown Flap Sling Bag', 899], [303, 'Grey Reflective Mini Sling', 699],
  [304, 'Black Flap Sling Bag', 899], [305, 'Tan Stitched Sling Bag', 999], [306, 'Black Multi-Zip Sling Bag', 899],
  [307, 'Brown Mini Crossbody', 799], [308, 'Grey Flap Sling Bag', 899], [309, 'Tan Round-Top Sling', 799],
  [310, 'Dark Brown Zip Sling Bag', 999], [311, 'Brown Vintage Sling Bag', 899], [312, 'Black & Tan Sling Bag', 899],
  [313, 'Black Diagonal-Stitch Sling', 899], [314, 'Brown Two-Tone Sling Bag', 899], [315, 'Grey Pocket Sling Bag', 999],
  [316, 'Tan & Black Sling Bag', 899], [317, 'Tan Classic Sling Bag', 899], [318, 'Burgundy Mini Crossbody', 799],
  [319, 'Tan Flap Sling Bag', 899], [320, 'Tan Zip Sling Bag', 999], [321, 'Black Stitched Sling Bag', 899],
];
const bagSet = (list, sub, desc, feats, baseOcc) => list.forEach(([code, name, price, occ]) => add({
  sku: `BG-${code}`, name, category: 'bags', subcategory: sub, price, mrp: est(price), moq: 1,
  description: `${name} — ${desc}`,
  features: feats, branding: ['Logo embroidery', 'Screen print', 'Metal logo badge'],
  bulkNote: 'Logo branding from 25 pcs', occasions: [...baseOcc, ...(occ || [])],
  images: [`/uploads/catalogue/bag-${code}.jpg`], sameDay: true,
  bestseller: [105, 120, 202, 214, 218, 302, 316].includes(code),
  newArrival: [101, 104, 122, 237, 239, 301].includes(code),
  featured: [107, 118, 222, 230, 305].includes(code),
}));
bagSet(backpacks, 'Backpacks', 'a dependable everyday backpack for office, college and travel. Photo shows the actual product; exact size and colour options confirmed on call.',
  ['Padded laptop compartment', 'Multiple organiser pockets', 'Comfortable padded straps', 'Logo branding available'], ['corporate', 'employee-welcome', 'for-him']);
bagSet(messengers, 'Laptop & Messenger Bags', 'a smart office bag with room for a laptop, documents and daily essentials. Exact size and colour options confirmed on call.',
  ['Fits most 14–15.6" laptops', 'Top handles + detachable shoulder strap', 'Multiple zip pockets', 'Logo branding available'], ['corporate', 'farewell', 'for-him']);
bagSet(slings, 'Sling Bags', 'a compact crossbody for phone, wallet and daily carry. Exact size and colour options confirmed on call.',
  ['Adjustable shoulder strap', 'Multiple zip pockets', 'Compact everyday size', 'Logo branding available'], ['for-him', 'birthday', 'corporate']);

// ---------- Notebooks (names & descriptions from the Notebook catalogue) ----------
// [code, name, sub, price, description, tags]
const GEN = 'An affordable choice known for exceptional writing quality, ideal for consumer gifting and trade promotions.';
const notebooks = [
  ['N-01', 'Velo', 'Classic Notebooks', 249, 'A slim, flexible soft-cover notebook in deep muted tones of plum, wine, charcoal and violet.', 'Flexible Cover · Slim Profile · Muted Palette'],
  ['N-10', 'Onyx', 'Classic Notebooks', 299, 'A timeless black hardcover with rounded corners, elastic closure and ribbon marker. Understated and professional.', 'Elastic Closure · Ribbon Marker · Rounded Corners'],
  ['N-11', 'Arlo', 'Classic Notebooks', 299, 'A structured hardcover in red, cobalt, tan and black, finished with neat edge stitching.', 'Stitched Edges · Ribbon Marker · 4 Colours'],
  ['N-12', 'Kora', 'Classic Notebooks', 329, 'A practical hardcover with a side pen loop and elastic band, made for people who write on the move.', 'Pen Loop · Elastic Band · Hard Cover'],
  ['N-13', 'Tempo', 'Classic Notebooks', 279, 'A smooth soft-touch notebook in five versatile shades. A dependable pick for bulk and seasonal gifting.', 'Soft-Touch Finish · Rounded Corners · 5 Colours'],
  ['N-14', 'Terra', 'Classic Notebooks', 399, 'A natural cork cover paired with a matching cork-finish pen. An earthy, eco-inspired set with real character.', 'Cork Cover · Matching Pen · Eco Look', ['eco']],
  ['N-21', 'Zeno', 'Classic Notebooks', 299, 'A clean hardcover in navy, tan, black, red and grey with a secure elastic closure. Simple, sturdy and easy to brand.', 'Elastic Closure · Ribbon Marker · 5 Colours'],
  ['N-22A', 'Pace', 'Classic Notebooks', 329, 'A work-ready hardcover in blue, black and tan with an integrated pen loop and elastic band.', 'Pen Loop · Elastic Band · Ribbon Marker'],
  ['N-22B', 'Zest', 'Classic Notebooks', 329, 'A vibrant hardcover in yellow, red, green and orange with a side pen loop and ribbon marker.', 'Pen Loop · Ribbon Marker · Bold Colours'],
  ['N-23', 'Sage', 'Classic Notebooks', 349, 'A textured cover in soft grey and taupe with a subtle embossed border. Calm, refined and tactile.', 'Textured Cover · Embossed Border · Ribbon Marker'],
  ['N-24', 'Duet', 'Classic Notebooks', 349, 'A two-tone notebook pairing a textured grey panel with warm brown. A modern contrast for style-led gifting.', 'Two-Tone Cover · Textured Panel'],
  ['N-31A', 'Flint', 'Executive Notebooks', 449, 'A classic executive notebook in five shades with a secure magnetic flap closure.', 'Magnetic Flap · Ribbon Marker · 5 Colours'],
  ['N-31B', 'Aurum', 'Executive Notebooks', 499, 'An executive notebook whose magnetic flap carries a polished gold-tone plate, ready for premium branding.', 'Gold-Tone Plate · Magnetic Flap'],
  ['N-32', 'Silva', 'Executive Notebooks', 499, 'An executive notebook with a sleek silver-tone plate on the magnetic flap. Crisp and corporate.', 'Silver-Tone Plate · Magnetic Flap'],
  ['N-33A', 'Nivo', 'Executive Notebooks', 449, 'A refined soft-textured cover led by denim blue, fastened with a polished silver metal tab.', 'Metal Tab Closure · Textured Cover'],
  ['N-33B', 'Brio', 'Executive Notebooks', 449, 'A deep charcoal cover with a brushed gold tab closure. Quietly luxurious.', 'Gold Tab Closure · Textured Cover'],
  ['N-33C', 'Gleam', 'Executive Notebooks', 449, 'A high-sheen cover in black, tan and navy with silver tab closures, for a polished boardroom look.', 'Glossy Finish · Metal Tab Closure'],
  ['N-34', 'Cord', 'Executive Notebooks', 399, 'A distinctive ribbed-texture cover in black, brown and blue with a slim strap closure.', 'Ribbed Texture · Strap Closure'],
  ['N-35A', 'Slate', 'Executive Notebooks', 499, 'A structured notebook with a flap closure and dark metallic plate, in grey, navy, black and tan.', 'Metal Plate · Flap Closure'],
  ['N-35B', 'Amber', 'Executive Notebooks', 499, 'A warm tan cover with a gold-tone plate on the flap. Rich, inviting and gift-ready.', 'Gold-Tone Plate · Flap Closure'],
  ['N-36', 'Regal', 'Executive Notebooks', 549, 'A wide flap closure carries a large gold-tone plate — a bold canvas for logo branding.', 'Large Branding Plate · Flap Closure'],
  ['N-37', 'Noir', 'Executive Notebooks', 549, 'An all-black notebook with a sculpted chrome plate on the flap. Sleek, modern and authoritative.', 'Chrome Plate · Magnetic Flap'],
  ['N-38', 'Halo', 'Executive Notebooks', 499, 'A round gold medallion on the flap gives this notebook a signature look, in brown, grey and tan.', 'Round Medallion · Flap Closure'],
  ['N-39', 'Wren', 'Executive Notebooks', 399, 'A minimal wrap-flap notebook in tan, brown and black. Clean lines with no hardware.', 'Wrap Flap · Minimal Design'],
  ['N-40', 'Clasp', 'Executive Notebooks', 449, 'A secure snap-button strap closure in navy, tan and black. Classic and dependable.', 'Snap Button Strap · Ribbon Marker'],
  ['N-41', 'Rivet', 'Executive Notebooks', 449, 'A snap-stud strap closure, shown in black and a vivid royal blue.', 'Snap Button Strap · Bold Blue Option'],
  ['N-42', 'Kaya', 'Executive Notebooks', 549, 'A natural bamboo-finish cover with a black spine and a flap that carries a metal plate.', 'Bamboo Finish · Metal Plate · Flap Closure', ['eco']],
  ['N-43', 'Atlas', 'Executive Notebooks', 699, 'An organiser-style notebook in black with tan trim, with a gold-tone plate, pen holder and inside pockets.', 'Pen Holder · Card Slots · Phone Pocket'],
  ['N-62', 'Tweed', 'Executive Notebooks', 499, 'Tan and sage covers with a woven-texture front panel, a debossed spine tab and a gold-tone plate.', 'Woven Panel · Gold-Tone Plate · 2 Colours'],
  ['N-71', 'Scout', 'Classic Notebooks', 349, 'A soft-textured notebook with a clean stitched front detail, in black, navy, tan and grey.', 'Stitched Detailing · 4 Colours'],
  ['N-72', 'Muse', 'Classic Notebooks', 399, 'A minimal soft-cover notebook in brown and charcoal with a refillable ring-style spine.', 'Soft Cover · Refillable Spine'],
  ['N-81', 'Folio', 'Classic Notebooks', 349, 'An envelope-style stitched flap on a rich brown cover. Elegant and slightly vintage.', 'Envelope Flap · Ribbon Marker'],
  ['N-82', 'Ember', 'Classic Notebooks', 379, 'A warm rust envelope-flap cover accented with a slim metal bar.', 'Envelope Flap · Metal Accent'],
  ['N-101', 'Cedar', 'Classic Notebooks', 299, 'A classic brown hardcover with fine stitched borders. Traditional and dependable.', 'Stitched Border · Ribbon Marker'],
  ['N-201', 'Petal', 'Executive Notebooks', 449, 'An embossed scalloped panel on green, rust and grey covers. A fresh, design-led statement.', 'Embossed Panel · 3 Colours'],
  ['N-202', 'Cove', 'Executive Notebooks', 449, 'A two-tone envelope-flap notebook with a woven texture, in tan, denim blue and green.', 'Envelope Flap · Two-Tone Texture'],
  ['N-203', 'Delta', 'Executive Notebooks', 449, 'An angled overlay flap with a tan accent strip on woven-texture covers in black, green and blue.', 'Angled Flap · Accent Strip'],
  ['N-204', 'Forward', 'Premium Collection', 399, `Two-tone covers with a centre pen loop, in black, grey, navy and brown. ${GEN}`, 'Pen Loop · Two-Tone Cover'],
  ['N-205', 'Dynamic', 'Premium Collection', 449, `Black and brown covers with a round mirror-finish accent. ${GEN}`, 'Metal Accent · Two-Tone'],
  ['N-206', 'Active', 'Premium Collection', 449, `A black cover with a curved beige and tan panel and strap. ${GEN}`, 'Curved Panel · Strap Closure'],
  ['N-207', 'Momentum', 'Premium Collection', 449, `Blue and black covers with a woven grey band and metal plate. ${GEN}`, 'Woven Band · Metal Plate'],
  ['N-208', 'Catalyst', 'Premium Collection', 429, `Grey and brown covers with a wide black elastic band and metal plate. ${GEN}`, 'Elastic Band · Metal Plate'],
  ['N-209', 'Vision', 'Premium Collection', 499, `A bamboo-look cover with a brown curved flap and metal button. ${GEN}`, 'Bamboo Look · Button Flap', ['eco']],
  ['N-210', 'Inspire', 'Premium Collection', 499, `A brown and beige two-tone cover with a round cut-out closure. ${GEN}`, 'Two-Tone Cover · Round Closure'],
  ['N-211', 'Achievement', 'Premium Collection', 449, `A clean black cover with a built-in pen slot on the front. ${GEN}`, 'Pen Slot · Minimal Design'],
  ['N-212', 'Success', 'Premium Collection', 549, `Rust and charcoal covers on a wooden-look spine with a metal emblem clasp. ${GEN}`, 'Metal Emblem · Magnetic Clasp'],
  ['N-213', 'Progress', 'Premium Collection', 499, `Grey, tan and navy covers with a metal name plate on the flap. ${GEN}`, 'Metal Plate · Flap Closure'],
  ['N-214', 'Performance', 'Premium Collection', 449, `A bamboo spine paired with blue, white or black covers. ${GEN}`, 'Bamboo Spine · 3 Colours', ['eco']],
  ['N-215', 'Excellence', 'Premium Collection', 449, `Blue, brown and black covers with a round metal button. ${GEN}`, 'Round Button · 3 Colours'],
  ['N-216', 'Premium Quality', 'Premium Collection', 499, `Denim-texture covers with a bamboo accent and loop closure. ${GEN}`, 'Denim Texture · Bamboo Accent', ['eco']],
  ['N-217', 'Superior Quality', 'Premium Collection', 499, `Tan, navy and black covers with a slim metal plate. ${GEN}`, 'Metal Plate · 3 Colours'],
  ['N-218', 'Distinctive', 'Premium Collection', 549, `Grey, tan, black and navy covers with a gold-tone plate. ${GEN}`, 'Gold-Tone Plate · 4 Colours'],
  ['N-219', 'Refined', 'Premium Collection', 449, `A black cover with a vertical bamboo stripe and elastic band. ${GEN}`, 'Bamboo Stripe · Elastic Band', ['eco']],
  ['N-220', 'Culmination', 'Premium Collection', 549, `A black cover with a large bamboo panel and black flap closure. ${GEN}`, 'Bamboo Panel · Flap Closure', ['eco']],
];
notebooks.forEach(([code, name, sub, price, desc, tags, occ], i) => add({
  sku: code, name: `${name} Notebook`.replace('Notebook Notebook', 'Notebook'), category: 'notebooks', subcategory: sub,
  price, mrp: est(price), moq: 1, description: desc,
  features: [...tags.split(' · '), 'Ruled pages'], branding: ['Logo debossing', 'Name foiling', 'Engraved metal plate'],
  bulkNote: 'Logo branding from 50 pcs', occasions: ['corporate', 'employee-welcome', 'diwali', ...(occ || [])],
  images: [`/uploads/catalogue/nb-${String(i + 1).padStart(2, '0')}.jpg`], sameDay: true,
  bestseller: ['N-10', 'N-31B', 'N-36', 'N-43', 'N-212'].includes(code),
  newArrival: ['N-201', 'N-214', 'N-219', 'N-220'].includes(code),
  featured: ['N-14', 'N-42', 'N-37'].includes(code),
}));

// ---------- Diary & Pen Gift Sets (DG codes from the Gift Set catalogue) ----------
const giftSets = [
  'Bamboo-Finish Diary & Pen Set', 'Red Diary & Pen Set', 'Tan Strap Diary & Pen Set', 'Navy Diary & Pen Set', 'Sage Gold-Plate Diary & Pen Set',
  'Charcoal Magnetic Diary & Pen Set', 'Denim Envelope Diary & Pen Set', 'Blue Magnetic Diary & Pen Set', 'Grey Scalloped Diary & Pen Set', 'Tan Envelope Diary & Pen Set',
  'Grey Classic Diary & Pen Set', 'Navy Classic Diary & Pen Set', 'Tan Organiser Diary & Pen Set', 'Red Classic Diary & Pen Set', 'Blue Strap Diary & Pen Set',
  'Card Holder & Pen Set', 'Brown Rose-Gold Bar Diary & Pen Set', 'Charcoal Wrap Diary & Pen Set', 'Taupe Diary & Pen Set', 'Red Hardcover Diary & Pen Set',
  'Rust Diary & Pen Set', 'Tan Scalloped Diary & Pen Set', 'Black Strap Diary & Pen Set', 'Royal Blue Snap Diary & Pen Set', 'Tan Suede-Panel Diary & Pen Set',
  'Sage Scalloped Diary & Pen Set', 'Navy Hardcover Diary & Pen Set', 'Rust Hardcover Diary & Pen Set', 'Grey Hardcover Diary & Pen Set', 'Silver-Grey Diary & Pen Set',
  'Navy Snap Diary & Pen Set', 'Brown Gold-Plate Diary & Pen Set', 'Tan & Mustard Diary & Pen Set', 'Light Grey Diary & Pen Set', 'Black & Tan Organiser Gift Set',
];
const gsPrice = [899, 699, 849, 699, 899, 849, 799, 849, 849, 799, 699, 699, 999, 699, 849, 799, 899, 799, 699, 699,
  749, 849, 849, 849, 849, 849, 699, 699, 699, 699, 849, 899, 799, 699, 999];
giftSets.forEach((name, i) => {
  const code = `DG-${String(i + 1).padStart(2, '0')}`;
  const isCard = i === 15;
  add({
    sku: code, name, category: 'gift-sets', subcategory: 'Diary & Pen Gift Sets', price: gsPrice[i], mrp: est(gsPrice[i]), moq: 1,
    description: isCard
      ? 'A leather card holder paired with a matching pen in a white presentation box — a polished gift for clients and new joiners.'
      : 'A premium diary paired with a matching pen, presented in a rigid grey gift box. Ready to gift as-is, or branded with your logo for clients and teams.',
    features: isCard ? ['Card holder + pen', 'White presentation box', 'Logo branding available'] : ['A5 diary + pen', 'Rigid gift box', 'Logo debossing on the diary', 'Pen engraving available'],
    branding: ['Logo debossing on diary', 'Pen laser engraving', 'Custom sleeve & card'],
    bulkNote: 'Logo branding from 25 sets', occasions: ['corporate', 'employee-welcome', 'diwali', 'farewell'],
    images: [`/uploads/catalogue/dg-${String(i + 1).padStart(2, '0')}.jpg`], sameDay: true,
    bestseller: [1, 5, 13, 32, 35].includes(i + 1), newArrival: [16, 25, 33].includes(i + 1), featured: [1, 13, 35].includes(i + 1),
  });
});

// ---------- Card Holders (W codes from the Visiting Card catalogue) ----------
const cardHolders = [
  ['W-01', 'Executive Card Holder', 399], ['W-02', 'Prestige Card Holder', 349], ['W-03', 'Elite Card Holder', 399],
  ['W-04', 'Signature Card Holder', 379], ['W-05', 'Signature Edge Card Holder', 379], ['W-06', 'Metal Edge Card Holder', 349],
  ['W-07', 'Premium Business Card Holder', 449], ['W-08', 'Classic Metal Card Holder', 299],
];
cardHolders.forEach(([code, name, price]) => add({
  sku: code, name, category: 'gift-sets', subcategory: 'Card Holders', price, mrp: est(price), moq: 1,
  description: `${name} — a slim metal and leatherette case that keeps business cards crisp. Ideal for client gifting and trade promotions.`,
  features: ['Holds ~15 business cards', 'Metal + leatherette finish', 'Magnetic / snap lid', 'Logo engraving available'],
  branding: ['Laser engraving (logo)', 'Laser engraving (name)'],
  bulkNote: 'Logo branding from 50 pcs', occasions: ['corporate', 'for-him', 'farewell'],
  images: [`/uploads/catalogue/ch-${code.slice(2)}.jpg`], sameDay: true,
  bestseller: ['W-01', 'W-07'].includes(code), newArrival: ['W-05'].includes(code), featured: false,
}));

const settings = {
  storeName: 'lastminutegifting',
  tagline: 'Gifts delivered in 2–4 hours across Delhi',
  phone: '+91 00000 00000',
  whatsapp: '910000000000',
  email: 'wegrowc@gmail.com',
  address: 'New Delhi, India',
  cities: [
    { slug: 'delhi', name: 'Delhi', active: true },
    { slug: 'noida', name: 'Noida', active: false },
    { slug: 'gurugram', name: 'Gurugram', active: false },
    { slug: 'chandigarh', name: 'Chandigarh', active: false },
  ],
  announcement: 'Order by 8 PM for same-day delivery in Delhi · Bulk & corporate orders welcome',
};

write('categories', { categories, occasions });
write('products', products);
const settingsFile = path.join(__dirname, '..', 'data', 'settings.json');
if (!fs.existsSync(settingsFile) || process.argv.includes('--reset-settings')) write('settings', settings);
if (!fs.existsSync(path.join(__dirname, '..', 'data', 'enquiries.json'))) write('enquiries', []);
console.log(`Seeded ${categories.length} categories, ${products.length} products.`);
