// Import / update products from a CSV (export your Excel sheet as CSV).
// Usage:  npm run import -- data/my-catalogue.csv            (merge: update by SKU, add new)
//         npm run import -- data/my-catalogue.csv --replace  (wipe sample products first)
// Columns (header row required; see data/catalogue-template.csv):
// sku,name,category,subcategory,price,mrp,moq,description,features,branding,occasions,images,featured,bestseller,newArrival,sameDay,inStock
// Multi-value columns (features, branding, occasions, images) use | as separator.
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
const { read, write } = require('../src/store');

const file = process.argv[2];
if (!file) {
  console.error('Usage: npm run import -- path/to/file.csv [--replace]');
  process.exit(1);
}
const replace = process.argv.includes('--replace');
const rows = parse(fs.readFileSync(path.resolve(file)), { columns: true, skip_empty_lines: true, trim: true, bom: true });

const slugify = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
const list = (v) => (v ? String(v).split('|').map((s) => s.trim()).filter(Boolean) : []);
const bool = (v, d) => (v === undefined || v === '' ? d : /^(1|y|yes|true)$/i.test(v));

const { categories = [] } = read('categories', {});
const catSlugs = new Set(categories.map((c) => c.slug));
let products = replace ? [] : read('products');
let nextId = Math.max(1000, ...products.map((p) => Number(p.id) || 0)) + 1;
let added = 0, updated = 0, skipped = 0;

for (const r of rows) {
  if (!r.name || !r.price) { skipped++; continue; }
  const category = catSlugs.has(slugify(r.category)) ? slugify(r.category) : slugify(r.category || 'gift-sets');
  if (!catSlugs.has(category)) console.warn(`  ! "${r.name}": category "${r.category}" is not in categories.json — add it there too.`);
  const data = {
    sku: r.sku || '',
    name: r.name,
    category,
    subcategory: r.subcategory || '',
    price: Number(r.price),
    mrp: Number(r.mrp) || Number(r.price),
    moq: Number(r.moq) || 1,
    bulkNote: r.bulkNote || 'Special pricing from 25+ units',
    description: r.description || '',
    features: list(r.features),
    branding: list(r.branding),
    occasions: list(r.occasions).map(slugify),
    images: list(r.images),
    featured: bool(r.featured, false),
    bestseller: bool(r.bestseller, false),
    newArrival: bool(r.newArrival, false),
    sameDay: bool(r.sameDay, true),
    inStock: bool(r.inStock, true),
  };
  const existing = data.sku && products.find((p) => p.sku === data.sku);
  if (existing) {
    Object.assign(existing, data);
    updated++;
  } else {
    const id = String(nextId++);
    let slug = slugify(r.name);
    if (products.some((p) => p.slug === slug)) slug += '-' + id;
    products.push({ id, slug, ...data, sku: data.sku || 'LMG-' + id, createdAt: new Date().toISOString() });
    added++;
  }
}

write('products', products);
console.log(`Done: ${added} added, ${updated} updated, ${skipped} skipped. Total products: ${products.length}`);
