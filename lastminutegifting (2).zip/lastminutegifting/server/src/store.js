// Tiny JSON-file data store. Swap for MongoDB later without touching routes:
// every route only uses the functions exported here.
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const files = {
  products: path.join(DATA_DIR, 'products.json'),
  categories: path.join(DATA_DIR, 'categories.json'),
  enquiries: path.join(DATA_DIR, 'enquiries.json'),
  settings: path.join(DATA_DIR, 'settings.json'),
};

function read(name, fallback = []) {
  try {
    return JSON.parse(fs.readFileSync(files[name], 'utf8'));
  } catch {
    return fallback;
  }
}

function write(name, data) {
  const tmp = files[name] + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, files[name]); // atomic replace
}

module.exports = { read, write, DATA_DIR };
