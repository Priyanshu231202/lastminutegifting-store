require('dotenv').config();
const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { nanoid, customAlphabet } = require('nanoid');
const enqId = customAlphabet('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 6);
const { read, write } = require('./store');
const { notify } = require('./notify');

const app = express();
const PORT = process.env.PORT || 5000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'change-me';
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d' }));

const slugify = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
const publicSettings = () => {
  const s = read('settings', {});
  return s;
};

/* ---------------- Public API ---------------- */

app.get('/api/health', (_, res) => res.json({ ok: true }));

app.get('/api/settings', (_, res) => res.json(publicSettings()));

app.get('/api/categories', (_, res) => {
  const { categories = [], occasions = [] } = read('categories', {});
  const products = read('products');
  const withCounts = categories.map((c) => ({
    ...c,
    count: products.filter((p) => p.category === c.slug).length,
    subs: (c.subcategories || []).map((s) => {
      const inSub = products.filter((p) => p.category === c.slug && p.subcategory === s);
      return { name: s, slug: slugify(s), count: inSub.length, image: (inSub.find((p) => p.bestseller && p.images?.length) || inSub.find((p) => p.images?.length))?.images[0] || null };
    }),
    // first product photo in the category doubles as its tile image
    image: c.image || products.find((p) => p.category === c.slug && p.images?.length)?.images[0] || null,
  }));
  res.json({ categories: withCounts, occasions });
});

// GET /api/products?category=&sub=&occasion=&q=&min=&max=&sort=&flag=&limit=&page=
app.get('/api/products', (req, res) => {
  const { category, sub, occasion, q, min, max, sort = 'featured', flag, sameDay } = req.query;
  const limit = Math.min(parseInt(req.query.limit) || 24, 100);
  const page = Math.max(parseInt(req.query.page) || 1, 1);
  let list = read('products');

  if (category) list = list.filter((p) => p.category === category);
  if (sub) list = list.filter((p) => slugify(p.subcategory) === slugify(sub));
  if (occasion) list = list.filter((p) => p.occasions?.includes(occasion));
  if (flag) list = list.filter((p) => p[flag]);
  if (sameDay === '1') list = list.filter((p) => p.sameDay);
  if (min) list = list.filter((p) => p.price >= Number(min));
  if (max) list = list.filter((p) => p.price <= Number(max));
  if (q) {
    const terms = q.toLowerCase().split(/\s+/).filter(Boolean);
    list = list.filter((p) => {
      const hay = `${p.name} ${p.category} ${p.subcategory} ${p.sku} ${(p.occasions || []).join(' ')}`.toLowerCase();
      return terms.every((t) => hay.includes(t));
    });
  }

  const sorters = {
    featured: (a, b) => (b.featured - a.featured) || (b.bestseller - a.bestseller),
    'price-asc': (a, b) => a.price - b.price,
    'price-desc': (a, b) => b.price - a.price,
    newest: (a, b) => new Date(b.createdAt) - new Date(a.createdAt),
    name: (a, b) => a.name.localeCompare(b.name),
  };
  list = [...list].sort(sorters[sort] || sorters.featured);

  const total = list.length;
  res.json({ total, page, pages: Math.ceil(total / limit), items: list.slice((page - 1) * limit, page * limit) });
});

app.get('/api/products/:slug', (req, res) => {
  const products = read('products');
  const product = products.find((p) => p.slug === req.params.slug || p.id === req.params.slug);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  const related = products
    .filter((p) => p.id !== product.id && (p.category === product.category || p.occasions?.some((o) => product.occasions?.includes(o))))
    .sort((a, b) => (b.category === product.category) - (a.category === product.category))
    .slice(0, 8);
  res.json({ product, related });
});

// Quote / bulk enquiry. body: { name, phone, email, company, city, deliveryDate, message, type, items:[{id, qty, branding}] }
app.post('/api/enquiries', async (req, res) => {
  const b = req.body || {};
  const errors = {};
  if (!b.name || b.name.trim().length < 2) errors.name = 'Please enter your name';
  if (!/^[6-9]\d{9}$/.test(String(b.phone || '').replace(/\D/g, '').slice(-10))) errors.phone = 'Enter a valid 10-digit mobile number';
  if (b.email && !/^\S+@\S+\.\S+$/.test(b.email)) errors.email = 'Enter a valid email';
  if (Object.keys(errors).length) return res.status(400).json({ errors });

  const products = read('products');
  const items = (Array.isArray(b.items) ? b.items : []).slice(0, 100).map((it) => {
    const p = products.find((x) => x.id === String(it.id));
    const qty = Math.max(parseInt(it.qty) || 1, 1);
    return p ? { id: p.id, sku: p.sku, name: p.name, price: p.price, qty, branding: it.branding || '', lineTotal: p.price * qty } : null;
  }).filter(Boolean);

  const enquiry = {
    id: 'ENQ-' + enqId(),
    type: b.type === 'bulk' ? 'bulk' : 'cart',
    status: 'new',
    name: String(b.name).trim().slice(0, 100),
    phone: String(b.phone).trim().slice(0, 20),
    email: String(b.email || '').trim().slice(0, 120),
    company: String(b.company || '').trim().slice(0, 120),
    city: String(b.city || 'delhi').slice(0, 40),
    deliveryDate: String(b.deliveryDate || '').slice(0, 20),
    budget: String(b.budget || '').slice(0, 40),
    quantity: String(b.quantity || '').slice(0, 20),
    message: String(b.message || '').trim().slice(0, 2000),
    items,
    estimatedTotal: items.reduce((s, i) => s + i.lineTotal, 0),
    createdAt: new Date().toISOString(),
  };
  const all = read('enquiries');
  all.unshift(enquiry);
  write('enquiries', all);
  notify(enquiry, publicSettings()).catch((e) => console.warn('Email notify failed:', e.message));
  res.status(201).json({ id: enquiry.id, estimatedTotal: enquiry.estimatedTotal });
});

/* ---------------- Admin API (Bearer token) ---------------- */

const admin = express.Router();
admin.use((req, res, next) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  if (token !== ADMIN_TOKEN) return res.status(401).json({ error: 'Unauthorized' });
  next();
});

admin.get('/check', (_, res) => res.json({ ok: true }));

admin.get('/enquiries', (_, res) => res.json(read('enquiries')));
admin.patch('/enquiries/:id', (req, res) => {
  const all = read('enquiries');
  const e = all.find((x) => x.id === req.params.id);
  if (!e) return res.status(404).json({ error: 'Not found' });
  if (req.body.status) e.status = req.body.status;
  if (typeof req.body.note === 'string') e.note = req.body.note;
  write('enquiries', all);
  res.json(e);
});
admin.delete('/enquiries/:id', (req, res) => {
  write('enquiries', read('enquiries').filter((x) => x.id !== req.params.id));
  res.json({ ok: true });
});

const cleanProduct = (body, existing = {}) => {
  const num = (v, d) => (v === '' || v == null || isNaN(Number(v)) ? d : Number(v));
  const arr = (v, d) => (Array.isArray(v) ? v : typeof v === 'string' ? v.split(',').map((s) => s.trim()).filter(Boolean) : d);
  const name = body.name ?? existing.name;
  return {
    ...existing,
    name,
    slug: body.slug ? slugify(body.slug) : existing.slug || slugify(name),
    sku: body.sku ?? existing.sku ?? '',
    category: body.category ?? existing.category,
    subcategory: body.subcategory ?? existing.subcategory ?? '',
    price: num(body.price, existing.price ?? 0),
    mrp: num(body.mrp, existing.mrp ?? 0),
    moq: num(body.moq, existing.moq ?? 1),
    bulkNote: body.bulkNote ?? existing.bulkNote ?? '',
    description: body.description ?? existing.description ?? '',
    features: arr(body.features, existing.features || []),
    branding: arr(body.branding, existing.branding || []),
    occasions: arr(body.occasions, existing.occasions || []),
    images: arr(body.images, existing.images || []),
    inStock: body.inStock ?? existing.inStock ?? true,
    featured: body.featured ?? existing.featured ?? false,
    bestseller: body.bestseller ?? existing.bestseller ?? false,
    newArrival: body.newArrival ?? existing.newArrival ?? false,
    sameDay: body.sameDay ?? existing.sameDay ?? true,
  };
};

admin.post('/products', (req, res) => {
  if (!req.body.name || !req.body.category) return res.status(400).json({ error: 'Name and category are required' });
  const products = read('products');
  const p = cleanProduct(req.body);
  if (products.some((x) => x.slug === p.slug)) p.slug += '-' + nanoid(4).toLowerCase();
  p.id = String(Math.max(1000, ...products.map((x) => Number(x.id) || 0)) + 1);
  if (!p.sku) p.sku = 'LMG-' + p.id;
  p.createdAt = new Date().toISOString();
  products.push(p);
  write('products', products);
  res.status(201).json(p);
});

admin.put('/products/:id', (req, res) => {
  const products = read('products');
  const i = products.findIndex((x) => x.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Not found' });
  products[i] = cleanProduct(req.body, products[i]);
  write('products', products);
  res.json(products[i]);
});

admin.delete('/products/:id', (req, res) => {
  write('products', read('products').filter((x) => x.id !== req.params.id));
  res.json({ ok: true });
});

const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (_, file, cb) => cb(null, `${Date.now()}-${nanoid(5)}${path.extname(file.originalname).toLowerCase()}`),
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => cb(null, /image\/(jpeg|png|webp|avif)/.test(file.mimetype)),
});
admin.post('/upload', upload.array('images', 10), (req, res) => {
  res.json({ urls: (req.files || []).map((f) => `/uploads/${f.filename}`) });
});

admin.put('/settings', (req, res) => {
  const s = { ...read('settings', {}), ...req.body };
  write('settings', s);
  res.json(s);
});

app.use('/api/admin', admin);

/* ---------------- Serve built React app in production ---------------- */
const CLIENT_DIST = path.join(__dirname, '..', '..', 'client', 'dist');
if (fs.existsSync(CLIENT_DIST)) {
  app.use(express.static(CLIENT_DIST));
  app.get(/^\/(?!api|uploads).*/, (_, res) => res.sendFile(path.join(CLIENT_DIST, 'index.html')));
}

app.use((err, req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Server error' });
});

app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
