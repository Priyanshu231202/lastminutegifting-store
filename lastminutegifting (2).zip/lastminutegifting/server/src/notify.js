// Emails a new enquiry to the store owner. Only runs if SMTP_* env vars are set
// (for Gmail: SMTP_HOST=smtp.gmail.com, SMTP_PORT=465, and an App Password).
const nodemailer = require('nodemailer');

async function notify(enq, settings) {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, NOTIFY_TO } = process.env;
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) return;
  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT) || 465,
    secure: Number(SMTP_PORT) !== 587,
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  });
  const rows = enq.items
    .map((i) => `<tr><td>${i.name} (${i.sku})</td><td>${i.qty}</td><td>₹${i.price}</td><td>${i.branding || '-'}</td></tr>`)
    .join('');
  await transporter.sendMail({
    from: `"${settings.storeName || 'Website'}" <${SMTP_USER}>`,
    to: NOTIFY_TO || settings.email || SMTP_USER,
    replyTo: enq.email || undefined,
    subject: `New ${enq.type === 'bulk' ? 'bulk' : 'quote'} enquiry ${enq.id} — ${enq.name}`,
    html: `<h2>${enq.id}</h2>
      <p><b>${enq.name}</b> ${enq.company ? '· ' + enq.company : ''}<br>
      📞 ${enq.phone} ${enq.email ? '· ✉️ ' + enq.email : ''}<br>
      City: ${enq.city} · Needed by: ${enq.deliveryDate || '-'} ${enq.quantity ? '· Qty: ' + enq.quantity : ''} ${enq.budget ? '· Budget: ' + enq.budget : ''}</p>
      ${rows ? `<table border="1" cellpadding="6" cellspacing="0"><tr><th>Item</th><th>Qty</th><th>Price</th><th>Branding</th></tr>${rows}</table>
      <p>Estimated: ₹${enq.estimatedTotal}</p>` : ''}
      <p>${(enq.message || '').replace(/</g, '&lt;')}</p>`,
  });
}

module.exports = { notify };
